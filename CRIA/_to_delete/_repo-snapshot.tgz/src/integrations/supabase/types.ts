export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account_deletion_log: {
        Row: {
          deleted_at: string | null
          email_hash: string
          id: string
          request_metadata: Json | null
          user_id_hash: string
        }
        Insert: {
          deleted_at?: string | null
          email_hash: string
          id?: string
          request_metadata?: Json | null
          user_id_hash: string
        }
        Update: {
          deleted_at?: string | null
          email_hash?: string
          id?: string
          request_metadata?: Json | null
          user_id_hash?: string
        }
        Relationships: []
      }
      account_members: {
        Row: {
          accepted_at: string | null
          id: string
          invited_at: string
          manager_notes: string | null
          member_email: string
          member_id: string | null
          owner_id: string
          pending_self_subscribe: boolean | null
          role: string
          status: string
        }
        Insert: {
          accepted_at?: string | null
          id?: string
          invited_at?: string
          manager_notes?: string | null
          member_email: string
          member_id?: string | null
          owner_id: string
          pending_self_subscribe?: boolean | null
          role?: string
          status?: string
        }
        Update: {
          accepted_at?: string | null
          id?: string
          invited_at?: string
          manager_notes?: string | null
          member_email?: string
          member_id?: string | null
          owner_id?: string
          pending_self_subscribe?: boolean | null
          role?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_members_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_members_owner_id_fkey"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_actions: {
        Row: {
          action: string
          admin_id: string
          created_at: string | null
          details: Json | null
          id: string
          target_user_id: string | null
        }
        Insert: {
          action: string
          admin_id: string
          created_at?: string | null
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Update: {
          action?: string
          admin_id?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_actions_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_actions_target_user_id_fkey"
            columns: ["target_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      agenda_captures: {
        Row: {
          capture_date: string
          capture_time: string | null
          client_name: string | null
          created_at: string | null
          crm_client_id: string | null
          id: string
          location: string | null
          manager_id: string
          note: string | null
          status: string | null
          team: string | null
        }
        Insert: {
          capture_date: string
          capture_time?: string | null
          client_name?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          id?: string
          location?: string | null
          manager_id: string
          note?: string | null
          status?: string | null
          team?: string | null
        }
        Update: {
          capture_date?: string
          capture_time?: string | null
          client_name?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          id?: string
          location?: string | null
          manager_id?: string
          note?: string | null
          status?: string | null
          team?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_captures_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      agenda_creations: {
        Row: {
          client_name: string | null
          created_at: string | null
          crm_client_id: string | null
          day: string
          id: string
          manager_id: string
          note: string | null
          team: string | null
        }
        Insert: {
          client_name?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          day: string
          id?: string
          manager_id: string
          note?: string | null
          team?: string | null
        }
        Update: {
          client_name?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          day?: string
          id?: string
          manager_id?: string
          note?: string | null
          team?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agenda_creations_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_rate_limit: {
        Row: {
          call_count: number
          id: string
          user_id: string
          window_start: string
        }
        Insert: {
          call_count?: number
          id?: string
          user_id: string
          window_start?: string
        }
        Update: {
          call_count?: number
          id?: string
          user_id?: string
          window_start?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_rate_limit_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      app_logs: {
        Row: {
          context: Json | null
          created_at: string
          id: string
          level: string
          message: string
          url: string | null
          user_id: string | null
        }
        Insert: {
          context?: Json | null
          created_at?: string
          id?: string
          level?: string
          message: string
          url?: string | null
          user_id?: string | null
        }
        Update: {
          context?: Json | null
          created_at?: string
          id?: string
          level?: string
          message?: string
          url?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      approval_tokens: {
        Row: {
          active: boolean
          created_at: string
          expires_at: string | null
          external_client_id: string
          id: string
          last_viewed_at: string | null
          manager_id: string
          period_end: string | null
          period_start: string | null
          token: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          expires_at?: string | null
          external_client_id: string
          id?: string
          last_viewed_at?: string | null
          manager_id: string
          period_end?: string | null
          period_start?: string | null
          token?: string
        }
        Update: {
          active?: boolean
          created_at?: string
          expires_at?: string | null
          external_client_id?: string
          id?: string
          last_viewed_at?: string | null
          manager_id?: string
          period_end?: string | null
          period_start?: string | null
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "approval_tokens_external_client_id_fkey"
            columns: ["external_client_id"]
            isOneToOne: false
            referencedRelation: "external_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          created_at: string | null
          entity_id: string | null
          entity_type: string | null
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "audit_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      autopilot_runs: {
        Row: {
          created_at: string
          foco: string | null
          id: string
          periodo: string
          posts: Json
          qtd: number
          user_id: string
        }
        Insert: {
          created_at?: string
          foco?: string | null
          id?: string
          periodo?: string
          posts?: Json
          qtd?: number
          user_id: string
        }
        Update: {
          created_at?: string
          foco?: string | null
          id?: string
          periodo?: string
          posts?: Json
          qtd?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "autopilot_runs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      billing_events: {
        Row: {
          event_id: string
          gateway: string
          id: string
          payload: Json | null
          processed_at: string | null
          type: string
        }
        Insert: {
          event_id: string
          gateway: string
          id?: string
          payload?: Json | null
          processed_at?: string | null
          type: string
        }
        Update: {
          event_id?: string
          gateway?: string
          id?: string
          payload?: Json | null
          processed_at?: string | null
          type?: string
        }
        Relationships: []
      }
      bio_leads: {
        Row: {
          created_at: string
          email: string | null
          id: string
          name: string | null
          phone: string | null
          source: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          name?: string | null
          phone?: string | null
          source?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          name?: string | null
          phone?: string | null
          source?: string
          user_id?: string
        }
        Relationships: []
      }
      bio_links: {
        Row: {
          clicks: number | null
          created_at: string | null
          icon: string | null
          id: string
          is_active: boolean | null
          link_type: string | null
          position: number | null
          thumbnail_url: string | null
          title: string
          url: string
          user_id: string
        }
        Insert: {
          clicks?: number | null
          created_at?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          link_type?: string | null
          position?: number | null
          thumbnail_url?: string | null
          title: string
          url: string
          user_id: string
        }
        Update: {
          clicks?: number | null
          created_at?: string | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          link_type?: string | null
          position?: number | null
          thumbnail_url?: string | null
          title?: string
          url?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bio_links_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      brand_items: {
        Row: {
          created_at: string | null
          id: string
          name: string
          position: number | null
          type: string
          user_id: string
          value: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          position?: number | null
          type: string
          user_id: string
          value?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          position?: number | null
          type?: string
          user_id?: string
          value?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "brand_items_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      broadcasts: {
        Row: {
          active: boolean
          audience: string
          created_at: string
          id: string
          level: string
          message: string
          title: string | null
        }
        Insert: {
          active?: boolean
          audience?: string
          created_at?: string
          id?: string
          level?: string
          message: string
          title?: string | null
        }
        Update: {
          active?: boolean
          audience?: string
          created_at?: string
          id?: string
          level?: string
          message?: string
          title?: string | null
        }
        Relationships: []
      }
      collab_deliverables: {
        Row: {
          collab_id: string
          created_at: string
          format: string | null
          id: string
          label: string
          post_id: string | null
          published: boolean
          published_at: string | null
          sort_order: number
          user_id: string
        }
        Insert: {
          collab_id: string
          created_at?: string
          format?: string | null
          id?: string
          label: string
          post_id?: string | null
          published?: boolean
          published_at?: string | null
          sort_order?: number
          user_id?: string
        }
        Update: {
          collab_id?: string
          created_at?: string
          format?: string | null
          id?: string
          label?: string
          post_id?: string | null
          published?: boolean
          published_at?: string | null
          sort_order?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "collab_deliverables_collab_id_fkey"
            columns: ["collab_id"]
            isOneToOne: false
            referencedRelation: "collabs"
            referencedColumns: ["id"]
          },
        ]
      }
      collabs: {
        Row: {
          archived: boolean
          brand: string
          briefing_url: string | null
          contact: string | null
          created_at: string
          deadline: string | null
          id: string
          notes: string | null
          objective: string | null
          proposal_client_comment: string | null
          proposal_decline_note: string | null
          proposal_decline_reason: string | null
          proposal_responded_at: string | null
          proposal_sent_at: string | null
          proposal_status: string
          proposal_terms: string | null
          proposal_token: string | null
          proposal_valid_until: string | null
          proposal_viewed_at: string | null
          status: string
          updated_at: string
          user_id: string
          value: number | null
        }
        Insert: {
          archived?: boolean
          brand: string
          briefing_url?: string | null
          contact?: string | null
          created_at?: string
          deadline?: string | null
          id?: string
          notes?: string | null
          objective?: string | null
          proposal_client_comment?: string | null
          proposal_decline_note?: string | null
          proposal_decline_reason?: string | null
          proposal_responded_at?: string | null
          proposal_sent_at?: string | null
          proposal_status?: string
          proposal_terms?: string | null
          proposal_token?: string | null
          proposal_valid_until?: string | null
          proposal_viewed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          value?: number | null
        }
        Update: {
          archived?: boolean
          brand?: string
          briefing_url?: string | null
          contact?: string | null
          created_at?: string
          deadline?: string | null
          id?: string
          notes?: string | null
          objective?: string | null
          proposal_client_comment?: string | null
          proposal_decline_note?: string | null
          proposal_decline_reason?: string | null
          proposal_responded_at?: string | null
          proposal_sent_at?: string | null
          proposal_status?: string
          proposal_terms?: string | null
          proposal_token?: string | null
          proposal_valid_until?: string | null
          proposal_viewed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          value?: number | null
        }
        Relationships: []
      }
      competitor_scrapes: {
        Row: {
          apify_run_id: string | null
          competitor_id: string | null
          cost_usd: number | null
          created_at: string
          crm_client_id: string | null
          error: string | null
          finished_at: string | null
          id: string
          input_handle: string
          manager_id: string
          result_summary: Json | null
          results_limit: number
          scrape_type: string
          status: string
        }
        Insert: {
          apify_run_id?: string | null
          competitor_id?: string | null
          cost_usd?: number | null
          created_at?: string
          crm_client_id?: string | null
          error?: string | null
          finished_at?: string | null
          id?: string
          input_handle: string
          manager_id: string
          result_summary?: Json | null
          results_limit?: number
          scrape_type: string
          status?: string
        }
        Update: {
          apify_run_id?: string | null
          competitor_id?: string | null
          cost_usd?: number | null
          created_at?: string
          crm_client_id?: string | null
          error?: string | null
          finished_at?: string | null
          id?: string
          input_handle?: string
          manager_id?: string
          result_summary?: Json | null
          results_limit?: number
          scrape_type?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "competitor_scrapes_competitor_id_fkey"
            columns: ["competitor_id"]
            isOneToOne: false
            referencedRelation: "hub_competitors"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "competitor_scrapes_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      content_trends: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          kind: string
          niche: string | null
          title: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          kind: string
          niche?: string | null
          title: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          kind?: string
          niche?: string | null
          title?: string
        }
        Relationships: []
      }
      course_purchases: {
        Row: {
          course_id: string
          id: string
          purchased_at: string | null
          user_id: string
        }
        Insert: {
          course_id: string
          id?: string
          purchased_at?: string | null
          user_id: string
        }
        Update: {
          course_id?: string
          id?: string
          purchased_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "course_purchases_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "course_purchases_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          content_url: string | null
          created_at: string | null
          description: string | null
          id: string
          is_included_pro: boolean | null
          position: number | null
          price_cents: number | null
          thumbnail_url: string | null
          title: string
        }
        Insert: {
          content_url?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_included_pro?: boolean | null
          position?: number | null
          price_cents?: number | null
          thumbnail_url?: string | null
          title: string
        }
        Update: {
          content_url?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_included_pro?: boolean | null
          position?: number | null
          price_cents?: number | null
          thumbnail_url?: string | null
          title?: string
        }
        Relationships: []
      }
      creative_ideas: {
        Row: {
          created_at: string
          crm_client_id: string | null
          format: string | null
          id: string
          manager_id: string
          rationale: string | null
          scrape_id: string | null
          source: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          crm_client_id?: string | null
          format?: string | null
          id?: string
          manager_id: string
          rationale?: string | null
          scrape_id?: string | null
          source?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          crm_client_id?: string | null
          format?: string | null
          id?: string
          manager_id?: string
          rationale?: string | null
          scrape_id?: string | null
          source?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "creative_ideas_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creative_ideas_scrape_id_fkey"
            columns: ["scrape_id"]
            isOneToOne: false
            referencedRelation: "competitor_scrapes"
            referencedColumns: ["id"]
          },
        ]
      }
      crm_client_refs: {
        Row: {
          created_at: string
          crm_client_id: string
          id: string
          image_url: string
          manager_id: string
          note: string | null
          sort_order: number
        }
        Insert: {
          created_at?: string
          crm_client_id: string
          id?: string
          image_url: string
          manager_id: string
          note?: string | null
          sort_order?: number
        }
        Update: {
          created_at?: string
          crm_client_id?: string
          id?: string
          image_url?: string
          manager_id?: string
          note?: string | null
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "crm_client_refs_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      crm_clients: {
        Row: {
          active: boolean
          address: string | null
          birthday: string | null
          brand_core: Json
          cnpj: string | null
          company_name: string | null
          competitors: Json
          contract_date: string | null
          created_at: string
          cria_owner_id: string | null
          crm_lead_id: string | null
          deleted_at: string | null
          diagnosis: Json
          email: string | null
          id: string
          instagram: string | null
          logo: string | null
          manager_id: string
          monthly_value: number | null
          name: string
          notes: string | null
          owner_name: string | null
          payment_day: number | null
          payment_method: string | null
          persona: Json
          phone: string | null
          plan_name: string | null
          renewal_date: string | null
          segment: string | null
          services: string[] | null
          status: string
          tags: string[]
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          active?: boolean
          address?: string | null
          birthday?: string | null
          brand_core?: Json
          cnpj?: string | null
          company_name?: string | null
          competitors?: Json
          contract_date?: string | null
          created_at?: string
          cria_owner_id?: string | null
          crm_lead_id?: string | null
          deleted_at?: string | null
          diagnosis?: Json
          email?: string | null
          id?: string
          instagram?: string | null
          logo?: string | null
          manager_id: string
          monthly_value?: number | null
          name: string
          notes?: string | null
          owner_name?: string | null
          payment_day?: number | null
          payment_method?: string | null
          persona?: Json
          phone?: string | null
          plan_name?: string | null
          renewal_date?: string | null
          segment?: string | null
          services?: string[] | null
          status?: string
          tags?: string[]
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          active?: boolean
          address?: string | null
          birthday?: string | null
          brand_core?: Json
          cnpj?: string | null
          company_name?: string | null
          competitors?: Json
          contract_date?: string | null
          created_at?: string
          cria_owner_id?: string | null
          crm_lead_id?: string | null
          deleted_at?: string | null
          diagnosis?: Json
          email?: string | null
          id?: string
          instagram?: string | null
          logo?: string | null
          manager_id?: string
          monthly_value?: number | null
          name?: string
          notes?: string | null
          owner_name?: string | null
          payment_day?: number | null
          payment_method?: string | null
          persona?: Json
          phone?: string | null
          plan_name?: string | null
          renewal_date?: string | null
          segment?: string | null
          services?: string[] | null
          status?: string
          tags?: string[]
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "crm_clients_cria_owner_id_fkey"
            columns: ["cria_owner_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crm_clients_crm_lead_id_fkey"
            columns: ["crm_lead_id"]
            isOneToOne: false
            referencedRelation: "crm_leads"
            referencedColumns: ["id"]
          },
        ]
      }
      crm_contracts: {
        Row: {
          closed_date: string | null
          contract_value: number | null
          created_at: string
          crm_client_id: string | null
          crm_lead_id: string | null
          ended_date: string | null
          id: string
          manager_id: string
          monthly_value: number | null
          notes: string | null
          sent_date: string | null
          status: string
          title: string
        }
        Insert: {
          closed_date?: string | null
          contract_value?: number | null
          created_at?: string
          crm_client_id?: string | null
          crm_lead_id?: string | null
          ended_date?: string | null
          id?: string
          manager_id: string
          monthly_value?: number | null
          notes?: string | null
          sent_date?: string | null
          status?: string
          title: string
        }
        Update: {
          closed_date?: string | null
          contract_value?: number | null
          created_at?: string
          crm_client_id?: string | null
          crm_lead_id?: string | null
          ended_date?: string | null
          id?: string
          manager_id?: string
          monthly_value?: number | null
          notes?: string | null
          sent_date?: string | null
          status?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "crm_contracts_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crm_contracts_crm_lead_id_fkey"
            columns: ["crm_lead_id"]
            isOneToOne: false
            referencedRelation: "crm_leads"
            referencedColumns: ["id"]
          },
        ]
      }
      crm_leads: {
        Row: {
          closing_potential: string | null
          color: string | null
          company: string | null
          created_at: string
          email: string | null
          id: string
          instagram: string | null
          is_referral: boolean | null
          lead_origin: string | null
          main_objection: string | null
          main_pain: string | null
          manager_id: string
          monthly_value: number | null
          name: string
          next_interaction_date: string | null
          next_steps: string | null
          notes: string | null
          phone: string | null
          referred_by: string | null
          segment: string | null
          stage: string
          updated_at: string
        }
        Insert: {
          closing_potential?: string | null
          color?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          instagram?: string | null
          is_referral?: boolean | null
          lead_origin?: string | null
          main_objection?: string | null
          main_pain?: string | null
          manager_id: string
          monthly_value?: number | null
          name: string
          next_interaction_date?: string | null
          next_steps?: string | null
          notes?: string | null
          phone?: string | null
          referred_by?: string | null
          segment?: string | null
          stage?: string
          updated_at?: string
        }
        Update: {
          closing_potential?: string | null
          color?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          id?: string
          instagram?: string | null
          is_referral?: boolean | null
          lead_origin?: string | null
          main_objection?: string | null
          main_pain?: string | null
          manager_id?: string
          monthly_value?: number | null
          name?: string
          next_interaction_date?: string | null
          next_steps?: string | null
          notes?: string | null
          phone?: string | null
          referred_by?: string | null
          segment?: string | null
          stage?: string
          updated_at?: string
        }
        Relationships: []
      }
      crm_saved_refs: {
        Row: {
          author: string | null
          created_at: string
          crm_client_id: string
          id: string
          manager_id: string
          note: string | null
          thumbnail_url: string | null
          title: string | null
          url: string
        }
        Insert: {
          author?: string | null
          created_at?: string
          crm_client_id: string
          id?: string
          manager_id: string
          note?: string | null
          thumbnail_url?: string | null
          title?: string | null
          url: string
        }
        Update: {
          author?: string | null
          created_at?: string
          crm_client_id?: string
          id?: string
          manager_id?: string
          note?: string | null
          thumbnail_url?: string | null
          title?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "crm_saved_refs_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      crm_tags: {
        Row: {
          color: string
          created_at: string | null
          id: string
          manager_id: string
          name: string
        }
        Insert: {
          color?: string
          created_at?: string | null
          id?: string
          manager_id: string
          name: string
        }
        Update: {
          color?: string
          created_at?: string | null
          id?: string
          manager_id?: string
          name?: string
        }
        Relationships: []
      }
      crm_tasks: {
        Row: {
          created_at: string
          crm_client_id: string | null
          crm_lead_id: string | null
          description: string | null
          due_date: string | null
          id: string
          manager_id: string
          priority: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          crm_client_id?: string | null
          crm_lead_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          manager_id?: string
          priority?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          crm_client_id?: string | null
          crm_lead_id?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          manager_id?: string
          priority?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "crm_tasks_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crm_tasks_crm_lead_id_fkey"
            columns: ["crm_lead_id"]
            isOneToOne: false
            referencedRelation: "crm_leads"
            referencedColumns: ["id"]
          },
        ]
      }
      cronograma_datas: {
        Row: {
          created_at: string | null
          cronograma_id: string
          day_label: string | null
          id: string
          label: string
          selected: boolean
          sort_order: number
        }
        Insert: {
          created_at?: string | null
          cronograma_id: string
          day_label?: string | null
          id?: string
          label: string
          selected?: boolean
          sort_order?: number
        }
        Update: {
          created_at?: string | null
          cronograma_id?: string
          day_label?: string | null
          id?: string
          label?: string
          selected?: boolean
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "cronograma_datas_cronograma_id_fkey"
            columns: ["cronograma_id"]
            isOneToOne: false
            referencedRelation: "cronogramas"
            referencedColumns: ["id"]
          },
        ]
      }
      cronograma_items: {
        Row: {
          approval_status: string
          client_comment: string | null
          converted_post_id: string | null
          copy: string | null
          created_at: string | null
          cronograma_id: string
          date: string | null
          description: string | null
          id: string
          sort_order: number
          type: string | null
          updated_at: string | null
        }
        Insert: {
          approval_status?: string
          client_comment?: string | null
          converted_post_id?: string | null
          copy?: string | null
          created_at?: string | null
          cronograma_id: string
          date?: string | null
          description?: string | null
          id?: string
          sort_order?: number
          type?: string | null
          updated_at?: string | null
        }
        Update: {
          approval_status?: string
          client_comment?: string | null
          converted_post_id?: string | null
          copy?: string | null
          created_at?: string | null
          cronograma_id?: string
          date?: string | null
          description?: string | null
          id?: string
          sort_order?: number
          type?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cronograma_items_converted_post_id_fkey"
            columns: ["converted_post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cronograma_items_cronograma_id_fkey"
            columns: ["cronograma_id"]
            isOneToOne: false
            referencedRelation: "cronogramas"
            referencedColumns: ["id"]
          },
        ]
      }
      cronogramas: {
        Row: {
          client_handle: string | null
          client_label: string | null
          created_at: string | null
          cria_owner_id: string | null
          crm_client_id: string | null
          external_client_id: string | null
          id: string
          manager_id: string
          status: string
          title: string
          token: string | null
          updated_at: string | null
        }
        Insert: {
          client_handle?: string | null
          client_label?: string | null
          created_at?: string | null
          cria_owner_id?: string | null
          crm_client_id?: string | null
          external_client_id?: string | null
          id?: string
          manager_id: string
          status?: string
          title: string
          token?: string | null
          updated_at?: string | null
        }
        Update: {
          client_handle?: string | null
          client_label?: string | null
          created_at?: string | null
          cria_owner_id?: string | null
          crm_client_id?: string | null
          external_client_id?: string | null
          id?: string
          manager_id?: string
          status?: string
          title?: string
          token?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cronogramas_external_client_id_fkey"
            columns: ["external_client_id"]
            isOneToOne: false
            referencedRelation: "external_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "cronogramas_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      email_send_log: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_id: string | null
          metadata: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email: string
          status: string
          template_name: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_id?: string | null
          metadata?: Json | null
          recipient_email?: string
          status?: string
          template_name?: string
        }
        Relationships: []
      }
      email_send_state: {
        Row: {
          auth_email_ttl_minutes: number
          batch_size: number
          id: number
          retry_after_until: string | null
          send_delay_ms: number
          transactional_email_ttl_minutes: number
          updated_at: string
        }
        Insert: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Update: {
          auth_email_ttl_minutes?: number
          batch_size?: number
          id?: number
          retry_after_until?: string | null
          send_delay_ms?: number
          transactional_email_ttl_minutes?: number
          updated_at?: string
        }
        Relationships: []
      }
      email_unsubscribe_tokens: {
        Row: {
          created_at: string
          email: string
          id: string
          token: string
          used_at: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          token: string
          used_at?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      external_clients: {
        Row: {
          active: boolean
          brand_color: string | null
          color: string | null
          created_at: string
          crm_client_id: string | null
          id: string
          instagram_handle: string | null
          logo_url: string | null
          manager_id: string
          name: string
          notes: string | null
          portal_settings: Json
        }
        Insert: {
          active?: boolean
          brand_color?: string | null
          color?: string | null
          created_at?: string
          crm_client_id?: string | null
          id?: string
          instagram_handle?: string | null
          logo_url?: string | null
          manager_id: string
          name: string
          notes?: string | null
          portal_settings?: Json
        }
        Update: {
          active?: boolean
          brand_color?: string | null
          color?: string | null
          created_at?: string
          crm_client_id?: string | null
          id?: string
          instagram_handle?: string | null
          logo_url?: string | null
          manager_id?: string
          name?: string
          notes?: string | null
          portal_settings?: Json
        }
        Relationships: [
          {
            foreignKeyName: "external_clients_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      external_media_refs: {
        Row: {
          bunny_video_id: string | null
          created_at: string | null
          download_url: string | null
          expires_at: string | null
          external_file_id: string
          file_name: string
          file_size: number | null
          file_type: string | null
          id: string
          position: number | null
          post_id: string | null
          provider: string
          thumbnail_url: string | null
          user_id: string
          view_url: string | null
        }
        Insert: {
          bunny_video_id?: string | null
          created_at?: string | null
          download_url?: string | null
          expires_at?: string | null
          external_file_id: string
          file_name: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          position?: number | null
          post_id?: string | null
          provider?: string
          thumbnail_url?: string | null
          user_id: string
          view_url?: string | null
        }
        Update: {
          bunny_video_id?: string | null
          created_at?: string | null
          download_url?: string | null
          expires_at?: string | null
          external_file_id?: string
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          position?: number | null
          post_id?: string | null
          provider?: string
          thumbnail_url?: string | null
          user_id?: string
          view_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "external_media_refs_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "external_media_refs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      feedbacks: {
        Row: {
          created_at: string
          id: string
          message: string
          status: string
          type: string
          url: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          status?: string
          type?: string
          url?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          status?: string
          type?: string
          url?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      files: {
        Row: {
          bunny_video_id: string | null
          category: string | null
          created_at: string | null
          expires_at: string | null
          file_type: string | null
          id: string
          name: string
          post_id: string | null
          size_bytes: number | null
          source: string | null
          storage_path: string
          tags: string[] | null
          user_id: string
        }
        Insert: {
          bunny_video_id?: string | null
          category?: string | null
          created_at?: string | null
          expires_at?: string | null
          file_type?: string | null
          id?: string
          name: string
          post_id?: string | null
          size_bytes?: number | null
          source?: string | null
          storage_path: string
          tags?: string[] | null
          user_id: string
        }
        Update: {
          bunny_video_id?: string | null
          category?: string | null
          created_at?: string | null
          expires_at?: string | null
          file_type?: string | null
          id?: string
          name?: string
          post_id?: string | null
          size_bytes?: number | null
          source?: string | null
          storage_path?: string
          tags?: string[] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "files_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      fin_monthly: {
        Row: {
          amount: number
          created_at: string
          crm_client_id: string | null
          due_date: string
          fin_record_id: string | null
          id: string
          manager_id: string
          month_ref: string
          paid_at: string | null
          skip_reason: string | null
          status: string
        }
        Insert: {
          amount?: number
          created_at?: string
          crm_client_id?: string | null
          due_date: string
          fin_record_id?: string | null
          id?: string
          manager_id: string
          month_ref: string
          paid_at?: string | null
          skip_reason?: string | null
          status?: string
        }
        Update: {
          amount?: number
          created_at?: string
          crm_client_id?: string | null
          due_date?: string
          fin_record_id?: string | null
          id?: string
          manager_id?: string
          month_ref?: string
          paid_at?: string | null
          skip_reason?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "fin_monthly_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fin_monthly_fin_record_id_fkey"
            columns: ["fin_record_id"]
            isOneToOne: false
            referencedRelation: "fin_records"
            referencedColumns: ["id"]
          },
        ]
      }
      fin_records: {
        Row: {
          amount: number
          category: string | null
          context: string
          created_at: string
          crm_client_id: string | null
          date: string
          description: string
          id: string
          manager_id: string
          payment_method: string | null
          recurring: boolean
          recurring_id: string | null
          status: string
          subcategory: string | null
          transfer_group: string | null
          type: string
          updated_at: string
        }
        Insert: {
          amount: number
          category?: string | null
          context?: string
          created_at?: string
          crm_client_id?: string | null
          date?: string
          description: string
          id?: string
          manager_id: string
          payment_method?: string | null
          recurring?: boolean
          recurring_id?: string | null
          status?: string
          subcategory?: string | null
          transfer_group?: string | null
          type: string
          updated_at?: string
        }
        Update: {
          amount?: number
          category?: string | null
          context?: string
          created_at?: string
          crm_client_id?: string | null
          date?: string
          description?: string
          id?: string
          manager_id?: string
          payment_method?: string | null
          recurring?: boolean
          recurring_id?: string | null
          status?: string
          subcategory?: string | null
          transfer_group?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fin_records_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fin_records_recurring_id_fkey"
            columns: ["recurring_id"]
            isOneToOne: false
            referencedRelation: "fin_recurring"
            referencedColumns: ["id"]
          },
        ]
      }
      fin_records_backup_100x: {
        Row: {
          amount: number | null
          category: string | null
          context: string | null
          created_at: string | null
          crm_client_id: string | null
          date: string | null
          description: string | null
          id: string | null
          manager_id: string | null
          payment_method: string | null
          recurring: boolean | null
          recurring_id: string | null
          status: string | null
          subcategory: string | null
          transfer_group: string | null
          type: string | null
          updated_at: string | null
        }
        Insert: {
          amount?: number | null
          category?: string | null
          context?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          date?: string | null
          description?: string | null
          id?: string | null
          manager_id?: string | null
          payment_method?: string | null
          recurring?: boolean | null
          recurring_id?: string | null
          status?: string | null
          subcategory?: string | null
          transfer_group?: string | null
          type?: string | null
          updated_at?: string | null
        }
        Update: {
          amount?: number | null
          category?: string | null
          context?: string | null
          created_at?: string | null
          crm_client_id?: string | null
          date?: string | null
          description?: string | null
          id?: string | null
          manager_id?: string | null
          payment_method?: string | null
          recurring?: boolean | null
          recurring_id?: string | null
          status?: string | null
          subcategory?: string | null
          transfer_group?: string | null
          type?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      fin_recurring: {
        Row: {
          active: boolean
          amount: number
          category: string | null
          context: string
          created_at: string
          crm_client_id: string | null
          description: string
          due_day: number
          end_date: string | null
          id: string
          manager_id: string
          payment_method: string | null
          start_date: string
          subcategory: string | null
          type: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          amount?: number
          category?: string | null
          context?: string
          created_at?: string
          crm_client_id?: string | null
          description: string
          due_day?: number
          end_date?: string | null
          id?: string
          manager_id: string
          payment_method?: string | null
          start_date?: string
          subcategory?: string | null
          type?: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          amount?: number
          category?: string | null
          context?: string
          created_at?: string
          crm_client_id?: string | null
          description?: string
          due_day?: number
          end_date?: string | null
          id?: string
          manager_id?: string
          payment_method?: string | null
          start_date?: string
          subcategory?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fin_recurring_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      google_drive_connections: {
        Row: {
          connected_at: string | null
          google_account_id: string
          google_email: string
          google_name: string | null
          id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          connected_at?: string | null
          google_account_id: string
          google_email: string
          google_name?: string | null
          id?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          connected_at?: string | null
          google_account_id?: string
          google_email?: string
          google_name?: string | null
          id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "google_drive_connections_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      habit_logs: {
        Row: {
          date: string
          done: boolean | null
          habit_id: string
          id: string
          user_id: string
        }
        Insert: {
          date: string
          done?: boolean | null
          habit_id: string
          id?: string
          user_id: string
        }
        Update: {
          date?: string
          done?: boolean | null
          habit_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habit_logs_habit_id_fkey"
            columns: ["habit_id"]
            isOneToOne: false
            referencedRelation: "habits"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "habit_logs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      habits: {
        Row: {
          created_at: string | null
          id: string
          name: string
          position: number | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          position?: number | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          position?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "habits_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      higgsfield_jobs: {
        Row: {
          aspect_ratio: string
          created_at: string
          error: string | null
          finished_at: string | null
          format: string
          id: string
          pages: Json
          post_id: string | null
          resolution: string
          status: string
          title: string
          user_id: string
        }
        Insert: {
          aspect_ratio?: string
          created_at?: string
          error?: string | null
          finished_at?: string | null
          format?: string
          id?: string
          pages?: Json
          post_id?: string | null
          resolution?: string
          status?: string
          title: string
          user_id: string
        }
        Update: {
          aspect_ratio?: string
          created_at?: string
          error?: string | null
          finished_at?: string | null
          format?: string
          id?: string
          pages?: Json
          post_id?: string | null
          resolution?: string
          status?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "higgsfield_jobs_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      hub_competitors: {
        Row: {
          avatar: string | null
          created_at: string
          crm_client_id: string | null
          followers: number | null
          handle: string
          id: string
          last_read_at: string | null
          manager_id: string
          name: string | null
          notes: string | null
        }
        Insert: {
          avatar?: string | null
          created_at?: string
          crm_client_id?: string | null
          followers?: number | null
          handle: string
          id?: string
          last_read_at?: string | null
          manager_id: string
          name?: string | null
          notes?: string | null
        }
        Update: {
          avatar?: string | null
          created_at?: string
          crm_client_id?: string | null
          followers?: number | null
          handle?: string
          id?: string
          last_read_at?: string | null
          manager_id?: string
          name?: string | null
          notes?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "hub_competitors_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
        ]
      }
      hub_credits: {
        Row: {
          extra: number
          manager_id: string
          month_start: string
          used: number
        }
        Insert: {
          extra?: number
          manager_id: string
          month_start: string
          used?: number
        }
        Update: {
          extra?: number
          manager_id?: string
          month_start?: string
          used?: number
        }
        Relationships: []
      }
      ideas: {
        Row: {
          created_at: string | null
          id: string
          idea_status: string | null
          notes: string | null
          objective: string | null
          origin: string | null
          pillar_id: string | null
          platform: string | null
          promoted_to_post_id: string | null
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          idea_status?: string | null
          notes?: string | null
          objective?: string | null
          origin?: string | null
          pillar_id?: string | null
          platform?: string | null
          promoted_to_post_id?: string | null
          title: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          idea_status?: string | null
          notes?: string | null
          objective?: string | null
          origin?: string | null
          pillar_id?: string | null
          platform?: string | null
          promoted_to_post_id?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ideas_pillar_id_fkey"
            columns: ["pillar_id"]
            isOneToOne: false
            referencedRelation: "pillars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ideas_promoted_to_post_fk"
            columns: ["promoted_to_post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ideas_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      manager_member_permissions: {
        Row: {
          all_clients: boolean | null
          client_ids: string[] | null
          created_at: string | null
          id: string
          member_row_id: string
          module_code: string
        }
        Insert: {
          all_clients?: boolean | null
          client_ids?: string[] | null
          created_at?: string | null
          id?: string
          member_row_id: string
          module_code: string
        }
        Update: {
          all_clients?: boolean | null
          client_ids?: string[] | null
          created_at?: string | null
          id?: string
          member_row_id?: string
          module_code?: string
        }
        Relationships: [
          {
            foreignKeyName: "manager_member_permissions_member_row_id_fkey"
            columns: ["member_row_id"]
            isOneToOne: false
            referencedRelation: "manager_members"
            referencedColumns: ["id"]
          },
        ]
      }
      manager_members: {
        Row: {
          created_at: string | null
          email: string | null
          id: string
          manager_id: string
          member_id: string
          name: string | null
          status: string | null
        }
        Insert: {
          created_at?: string | null
          email?: string | null
          id?: string
          manager_id: string
          member_id: string
          name?: string | null
          status?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string | null
          id?: string
          manager_id?: string
          member_id?: string
          name?: string | null
          status?: string | null
        }
        Relationships: []
      }
      manager_profiles: {
        Row: {
          billing_email: string | null
          business_name: string | null
          client_range: string | null
          contract_company: Json
          created_at: string
          fin_settings: Json
          full_name: string | null
          id: string
          instagram_handle: string | null
          niche: string | null
          tax_id: string | null
          updated_at: string
          user_id: string
          whatsapp: string | null
        }
        Insert: {
          billing_email?: string | null
          business_name?: string | null
          client_range?: string | null
          contract_company?: Json
          created_at?: string
          fin_settings?: Json
          full_name?: string | null
          id?: string
          instagram_handle?: string | null
          niche?: string | null
          tax_id?: string | null
          updated_at?: string
          user_id: string
          whatsapp?: string | null
        }
        Update: {
          billing_email?: string | null
          business_name?: string | null
          client_range?: string | null
          contract_company?: Json
          created_at?: string
          fin_settings?: Json
          full_name?: string | null
          id?: string
          instagram_handle?: string | null
          niche?: string | null
          tax_id?: string | null
          updated_at?: string
          user_id?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      media_items: {
        Row: {
          category: string | null
          created_at: string | null
          file_name: string
          file_type: string | null
          id: string
          storage_path: string
          tags: string[] | null
          user_id: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          file_name: string
          file_type?: string | null
          id?: string
          storage_path: string
          tags?: string[] | null
          user_id: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          file_name?: string
          file_type?: string | null
          id?: string
          storage_path?: string
          tags?: string[] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "media_items_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      media_kit_profiles: {
        Row: {
          accent: string | null
          audience: Json | null
          bio: string | null
          cities: string | null
          contact: string | null
          gender: Json | null
          headline: string | null
          link: string | null
          niche: string | null
          services: Json | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          accent?: string | null
          audience?: Json | null
          bio?: string | null
          cities?: string | null
          contact?: string | null
          gender?: Json | null
          headline?: string | null
          link?: string | null
          niche?: string | null
          services?: Json | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          accent?: string | null
          audience?: Json | null
          bio?: string | null
          cities?: string | null
          contact?: string | null
          gender?: Json | null
          headline?: string | null
          link?: string | null
          niche?: string | null
          services?: Json | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      milestones: {
        Row: {
          completed: boolean | null
          completed_at: string | null
          created_at: string | null
          goal_id: string
          id: string
          name: string
          position: number | null
          user_id: string
        }
        Insert: {
          completed?: boolean | null
          completed_at?: string | null
          created_at?: string | null
          goal_id: string
          id?: string
          name: string
          position?: number | null
          user_id: string
        }
        Update: {
          completed?: boolean | null
          completed_at?: string | null
          created_at?: string | null
          goal_id?: string
          id?: string
          name?: string
          position?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "milestones_goal_id_fkey"
            columns: ["goal_id"]
            isOneToOne: false
            referencedRelation: "structured_goals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "milestones_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      module_entitlements: {
        Row: {
          created_at: string
          current_period_end: string | null
          id: string
          manager_id: string
          module_code: string
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          manager_id: string
          module_code: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          id?: string
          manager_id?: string
          module_code?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "module_entitlements_module_code_fkey"
            columns: ["module_code"]
            isOneToOne: false
            referencedRelation: "modules"
            referencedColumns: ["code"]
          },
        ]
      }
      modules: {
        Row: {
          active: boolean
          code: string
          coming_soon: boolean
          created_at: string
          description: string | null
          name: string
          price_cents: number
          sort_order: number
          stripe_price_id: string | null
        }
        Insert: {
          active?: boolean
          code: string
          coming_soon?: boolean
          created_at?: string
          description?: string | null
          name: string
          price_cents: number
          sort_order?: number
          stripe_price_id?: string | null
        }
        Update: {
          active?: boolean
          code?: string
          coming_soon?: boolean
          created_at?: string
          description?: string | null
          name?: string
          price_cents?: number
          sort_order?: number
          stripe_price_id?: string | null
        }
        Relationships: []
      }
      monthly_goals: {
        Row: {
          created_at: string | null
          due_date: string | null
          focus: string | null
          goals: string[] | null
          id: string
          month: string
          reflection: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          due_date?: string | null
          focus?: string | null
          goals?: string[] | null
          id?: string
          month: string
          reflection?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          due_date?: string | null
          focus?: string | null
          goals?: string[] | null
          id?: string
          month?: string
          reflection?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "monthly_goals_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_reflections: {
        Row: {
          biz_blocked: string | null
          biz_clarity: string | null
          biz_procrastination: string | null
          biz_revenue: string | null
          biz_worked: string | null
          content_best: string | null
          content_connection: string | null
          content_rhythm: string | null
          created_at: string | null
          focus_distractions: string | null
          focus_execution: string | null
          focus_lessons: string | null
          id: string
          month: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          biz_blocked?: string | null
          biz_clarity?: string | null
          biz_procrastination?: string | null
          biz_revenue?: string | null
          biz_worked?: string | null
          content_best?: string | null
          content_connection?: string | null
          content_rhythm?: string | null
          created_at?: string | null
          focus_distractions?: string | null
          focus_execution?: string | null
          focus_lessons?: string | null
          id?: string
          month: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          biz_blocked?: string | null
          biz_clarity?: string | null
          biz_procrastination?: string | null
          biz_revenue?: string | null
          biz_worked?: string | null
          content_best?: string | null
          content_connection?: string | null
          content_rhythm?: string | null
          created_at?: string | null
          focus_distractions?: string | null
          focus_execution?: string | null
          focus_lessons?: string | null
          id?: string
          month?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "monthly_reflections_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      moodboard_entries: {
        Row: {
          answer: string | null
          created_at: string | null
          id: string
          question_key: string
          section: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          answer?: string | null
          created_at?: string | null
          id?: string
          question_key: string
          section: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          answer?: string | null
          created_at?: string | null
          id?: string
          question_key?: string
          section?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "moodboard_entries_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          link: string | null
          read: boolean | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          link?: string | null
          read?: boolean | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          link?: string | null
          read?: boolean | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      oauth_states: {
        Row: {
          created_at: string
          crm_client_id: string | null
          expires_at: string
          provider: string
          state: string
          user_id: string
        }
        Insert: {
          created_at?: string
          crm_client_id?: string | null
          expires_at?: string
          provider?: string
          state: string
          user_id: string
        }
        Update: {
          created_at?: string
          crm_client_id?: string | null
          expires_at?: string
          provider?: string
          state?: string
          user_id?: string
        }
        Relationships: []
      }
      partner_program_config: {
        Row: {
          deduction_pct: number
          grace_invoices: number
          id: boolean
          updated_at: string
        }
        Insert: {
          deduction_pct?: number
          grace_invoices?: number
          id?: boolean
          updated_at?: string
        }
        Update: {
          deduction_pct?: number
          grace_invoices?: number
          id?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      partner_referrals: {
        Row: {
          cancel_reason: string | null
          canceled_at: string | null
          created_at: string
          currency: string | null
          deduction_pct: number | null
          first_invoice_id: string | null
          gross_amount_cents: number | null
          id: string
          net_amount_cents: number | null
          paid_at: string | null
          paid_invoices_count: number
          partner_id: string
          payout_note: string | null
          payout_proof_url: string | null
          referred_user_id: string
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          unlocked_at: string | null
          updated_at: string
        }
        Insert: {
          cancel_reason?: string | null
          canceled_at?: string | null
          created_at?: string
          currency?: string | null
          deduction_pct?: number | null
          first_invoice_id?: string | null
          gross_amount_cents?: number | null
          id?: string
          net_amount_cents?: number | null
          paid_at?: string | null
          paid_invoices_count?: number
          partner_id: string
          payout_note?: string | null
          payout_proof_url?: string | null
          referred_user_id: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          unlocked_at?: string | null
          updated_at?: string
        }
        Update: {
          cancel_reason?: string | null
          canceled_at?: string | null
          created_at?: string
          currency?: string | null
          deduction_pct?: number | null
          first_invoice_id?: string | null
          gross_amount_cents?: number | null
          id?: string
          net_amount_cents?: number | null
          paid_at?: string | null
          paid_invoices_count?: number
          partner_id?: string
          payout_note?: string | null
          payout_proof_url?: string | null
          referred_user_id?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          unlocked_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "partner_referrals_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "partners"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "partner_referrals_referred_user_id_fkey"
            columns: ["referred_user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      partners: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          commission_deduction_pct: number | null
          coupon_code: string | null
          coupon_discount_pct: number | null
          coupon_duration_months: number | null
          coupon_type: string | null
          cpf: string | null
          created_at: string
          current_clients: string | null
          full_name: string | null
          id: string
          instagram_handle: string | null
          notes: string | null
          phone: string | null
          pix_key: string | null
          status: string
          stripe_coupon_id: string | null
          stripe_promotion_code_id: string | null
          time_active: string | null
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          commission_deduction_pct?: number | null
          coupon_code?: string | null
          coupon_discount_pct?: number | null
          coupon_duration_months?: number | null
          coupon_type?: string | null
          cpf?: string | null
          created_at?: string
          current_clients?: string | null
          full_name?: string | null
          id?: string
          instagram_handle?: string | null
          notes?: string | null
          phone?: string | null
          pix_key?: string | null
          status?: string
          stripe_coupon_id?: string | null
          stripe_promotion_code_id?: string | null
          time_active?: string | null
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          commission_deduction_pct?: number | null
          coupon_code?: string | null
          coupon_discount_pct?: number | null
          coupon_duration_months?: number | null
          coupon_type?: string | null
          cpf?: string | null
          created_at?: string
          current_clients?: string | null
          full_name?: string | null
          id?: string
          instagram_handle?: string | null
          notes?: string | null
          phone?: string | null
          pix_key?: string | null
          status?: string
          stripe_coupon_id?: string | null
          stripe_promotion_code_id?: string | null
          time_active?: string | null
          user_id?: string
        }
        Relationships: []
      }
      pending_purchases: {
        Row: {
          claimed_at: string | null
          claimed_by: string | null
          created_at: string
          email: string
          plan: string
          session_id: string
          status: string
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
        }
        Insert: {
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          email: string
          plan: string
          session_id: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
        }
        Update: {
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          email?: string
          plan?: string
          session_id?: string
          status?: string
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
        }
        Relationships: []
      }
      personas: {
        Row: {
          age_range: string | null
          created_at: string | null
          desires: string[] | null
          gender: string | null
          how_you_help: string | null
          icon: string | null
          id: string
          interests: string[] | null
          location: string | null
          name: string
          notes: string | null
          pain_points: string[] | null
          platforms: string[] | null
          user_id: string
        }
        Insert: {
          age_range?: string | null
          created_at?: string | null
          desires?: string[] | null
          gender?: string | null
          how_you_help?: string | null
          icon?: string | null
          id?: string
          interests?: string[] | null
          location?: string | null
          name?: string
          notes?: string | null
          pain_points?: string[] | null
          platforms?: string[] | null
          user_id: string
        }
        Update: {
          age_range?: string | null
          created_at?: string | null
          desires?: string[] | null
          gender?: string | null
          how_you_help?: string | null
          icon?: string | null
          id?: string
          interests?: string[] | null
          location?: string | null
          name?: string
          notes?: string | null
          pain_points?: string[] | null
          platforms?: string[] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "personas_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      pillars: {
        Row: {
          color: string
          created_at: string | null
          id: string
          name: string
          position: number | null
          user_id: string
        }
        Insert: {
          color: string
          created_at?: string | null
          id?: string
          name: string
          position?: number | null
          user_id: string
        }
        Update: {
          color?: string
          created_at?: string | null
          id?: string
          name?: string
          position?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pillars_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      post_approval_comments: {
        Row: {
          author_id: string | null
          author_role: string
          content: string
          created_at: string
          id: string
          post_id: string
        }
        Insert: {
          author_id?: string | null
          author_role?: string
          content: string
          created_at?: string
          id?: string
          post_id: string
        }
        Update: {
          author_id?: string | null
          author_role?: string
          content?: string
          created_at?: string
          id?: string
          post_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "post_approval_comments_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
        ]
      }
      posts: {
        Row: {
          approval_mode: string
          approval_stages: Json | null
          approval_status: string | null
          approval_updated_at: string | null
          archive_summary: string | null
          art: Json | null
          calendar_synced_at: string | null
          caption: string | null
          content_blocks: Json | null
          created_at: string | null
          cta: string | null
          deleted_at: string | null
          external_client_id: string | null
          format: string
          google_event_id: string | null
          hook: string | null
          id: string
          idea_id: string | null
          is_draft: boolean
          learnings: string | null
          notes: string | null
          pillar_id: string | null
          platform: string
          published_at: string | null
          reference_link: string | null
          result_comments: number | null
          result_reach: number | null
          result_saves: number | null
          result_shares: number | null
          result_views: number | null
          scheduled_date: string | null
          scheduled_time: string | null
          script: string | null
          sections: string | null
          status: string | null
          title: string
          updated_at: string | null
          user_id: string
          week_number: number | null
        }
        Insert: {
          approval_mode?: string
          approval_stages?: Json | null
          approval_status?: string | null
          approval_updated_at?: string | null
          archive_summary?: string | null
          art?: Json | null
          calendar_synced_at?: string | null
          caption?: string | null
          content_blocks?: Json | null
          created_at?: string | null
          cta?: string | null
          deleted_at?: string | null
          external_client_id?: string | null
          format: string
          google_event_id?: string | null
          hook?: string | null
          id?: string
          idea_id?: string | null
          is_draft?: boolean
          learnings?: string | null
          notes?: string | null
          pillar_id?: string | null
          platform: string
          published_at?: string | null
          reference_link?: string | null
          result_comments?: number | null
          result_reach?: number | null
          result_saves?: number | null
          result_shares?: number | null
          result_views?: number | null
          scheduled_date?: string | null
          scheduled_time?: string | null
          script?: string | null
          sections?: string | null
          status?: string | null
          title: string
          updated_at?: string | null
          user_id: string
          week_number?: number | null
        }
        Update: {
          approval_mode?: string
          approval_stages?: Json | null
          approval_status?: string | null
          approval_updated_at?: string | null
          archive_summary?: string | null
          art?: Json | null
          calendar_synced_at?: string | null
          caption?: string | null
          content_blocks?: Json | null
          created_at?: string | null
          cta?: string | null
          deleted_at?: string | null
          external_client_id?: string | null
          format?: string
          google_event_id?: string | null
          hook?: string | null
          id?: string
          idea_id?: string | null
          is_draft?: boolean
          learnings?: string | null
          notes?: string | null
          pillar_id?: string | null
          platform?: string
          published_at?: string | null
          reference_link?: string | null
          result_comments?: number | null
          result_reach?: number | null
          result_saves?: number | null
          result_shares?: number | null
          result_views?: number | null
          scheduled_date?: string | null
          scheduled_time?: string | null
          script?: string | null
          sections?: string | null
          status?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
          week_number?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "posts_external_client_id_fkey"
            columns: ["external_client_id"]
            isOneToOne: false
            referencedRelation: "external_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_idea_id_fkey"
            columns: ["idea_id"]
            isOneToOne: false
            referencedRelation: "ideas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_pillar_id_fkey"
            columns: ["pillar_id"]
            isOneToOne: false
            referencedRelation: "pillars"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "posts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          access_expires_at: string | null
          account_type: string
          agency_owner_id: string | null
          ai_ideas_reset_at: string | null
          ai_ideas_used_month: number | null
          avatar_url: string | null
          bio: string | null
          bio_settings: Json | null
          bio_slug: string | null
          bio_views: number | null
          brand_logo_url: string | null
          collab_seats_subscription_id: string | null
          created_at: string | null
          editorial_line: Json | null
          id: string
          instagram_handle: string | null
          last_seen_at: string | null
          media_kit_url: string | null
          must_change_password: boolean
          name: string
          niche: string | null
          onboarding_completed: boolean | null
          paid_collab_seats: number
          parked_at: string | null
          parked_until: string | null
          phone: string | null
          pix_key: string | null
          plan: string | null
          platforms: string[] | null
          role: string | null
          seat_limit: number | null
          storage_quota_bytes: number | null
          storage_retention_days: number | null
          storage_used_bytes: number | null
          stripe_customer_id: string | null
          stripe_subscription_id: string | null
          subscription_status: string | null
          terms_accepted_at: string | null
          terms_version: string | null
          theme_accent: string | null
          theme_bg: string | null
          theme_color: string | null
          theme_font: string | null
          theme_mode: string | null
          theme_preset: string | null
          theme_sidebar: string | null
          tiktok_handle: string | null
          trial_ends_at: string | null
          trial_started_at: string | null
          updated_at: string | null
          weekly_goal: number | null
          youtube_handle: string | null
        }
        Insert: {
          access_expires_at?: string | null
          account_type?: string
          agency_owner_id?: string | null
          ai_ideas_reset_at?: string | null
          ai_ideas_used_month?: number | null
          avatar_url?: string | null
          bio?: string | null
          bio_settings?: Json | null
          bio_slug?: string | null
          bio_views?: number | null
          brand_logo_url?: string | null
          collab_seats_subscription_id?: string | null
          created_at?: string | null
          editorial_line?: Json | null
          id: string
          instagram_handle?: string | null
          last_seen_at?: string | null
          media_kit_url?: string | null
          must_change_password?: boolean
          name: string
          niche?: string | null
          onboarding_completed?: boolean | null
          paid_collab_seats?: number
          parked_at?: string | null
          parked_until?: string | null
          phone?: string | null
          pix_key?: string | null
          plan?: string | null
          platforms?: string[] | null
          role?: string | null
          seat_limit?: number | null
          storage_quota_bytes?: number | null
          storage_retention_days?: number | null
          storage_used_bytes?: number | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: string | null
          terms_accepted_at?: string | null
          terms_version?: string | null
          theme_accent?: string | null
          theme_bg?: string | null
          theme_color?: string | null
          theme_font?: string | null
          theme_mode?: string | null
          theme_preset?: string | null
          theme_sidebar?: string | null
          tiktok_handle?: string | null
          trial_ends_at?: string | null
          trial_started_at?: string | null
          updated_at?: string | null
          weekly_goal?: number | null
          youtube_handle?: string | null
        }
        Update: {
          access_expires_at?: string | null
          account_type?: string
          agency_owner_id?: string | null
          ai_ideas_reset_at?: string | null
          ai_ideas_used_month?: number | null
          avatar_url?: string | null
          bio?: string | null
          bio_settings?: Json | null
          bio_slug?: string | null
          bio_views?: number | null
          brand_logo_url?: string | null
          collab_seats_subscription_id?: string | null
          created_at?: string | null
          editorial_line?: Json | null
          id?: string
          instagram_handle?: string | null
          last_seen_at?: string | null
          media_kit_url?: string | null
          must_change_password?: boolean
          name?: string
          niche?: string | null
          onboarding_completed?: boolean | null
          paid_collab_seats?: number
          parked_at?: string | null
          parked_until?: string | null
          phone?: string | null
          pix_key?: string | null
          plan?: string | null
          platforms?: string[] | null
          role?: string | null
          seat_limit?: number | null
          storage_quota_bytes?: number | null
          storage_retention_days?: number | null
          storage_used_bytes?: number | null
          stripe_customer_id?: string | null
          stripe_subscription_id?: string | null
          subscription_status?: string | null
          terms_accepted_at?: string | null
          terms_version?: string | null
          theme_accent?: string | null
          theme_bg?: string | null
          theme_color?: string | null
          theme_font?: string | null
          theme_mode?: string | null
          theme_preset?: string | null
          theme_sidebar?: string | null
          tiktok_handle?: string | null
          trial_ends_at?: string | null
          trial_started_at?: string | null
          updated_at?: string | null
          weekly_goal?: number | null
          youtube_handle?: string | null
        }
        Relationships: []
      }
      prompter_scripts: {
        Row: {
          created_at: string
          folder: string | null
          id: string
          script: string
          source: string
          source_id: string | null
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          folder?: string | null
          id?: string
          script?: string
          source?: string
          source_id?: string | null
          title?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          folder?: string | null
          id?: string
          script?: string
          source?: string
          source_id?: string | null
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "push_subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      rate_limit_v2: {
        Row: {
          count: number
          created_at: string
          id: string
          scope: string
          updated_at: string
          user_id: string
          window_key: string
        }
        Insert: {
          count?: number
          created_at?: string
          id?: string
          scope: string
          updated_at?: string
          user_id: string
          window_key: string
        }
        Update: {
          count?: number
          created_at?: string
          id?: string
          scope?: string
          updated_at?: string
          user_id?: string
          window_key?: string
        }
        Relationships: []
      }
      reference_formats: {
        Row: {
          format_type: string
          id: string
          is_active: boolean | null
          name: string
          platform: string
          structure: string
          tips: string | null
        }
        Insert: {
          format_type: string
          id?: string
          is_active?: boolean | null
          name: string
          platform: string
          structure: string
          tips?: string | null
        }
        Update: {
          format_type?: string
          id?: string
          is_active?: boolean | null
          name?: string
          platform?: string
          structure?: string
          tips?: string | null
        }
        Relationships: []
      }
      reference_hooks: {
        Row: {
          category: string
          example: string | null
          formats: string[] | null
          hook_text: string
          id: string
          is_active: boolean | null
          platforms: string[] | null
        }
        Insert: {
          category: string
          example?: string | null
          formats?: string[] | null
          hook_text: string
          id?: string
          is_active?: boolean | null
          platforms?: string[] | null
        }
        Update: {
          category?: string
          example?: string | null
          formats?: string[] | null
          hook_text?: string
          id?: string
          is_active?: boolean | null
          platforms?: string[] | null
        }
        Relationships: []
      }
      reference_prompts: {
        Row: {
          category: string
          id: string
          is_active: boolean | null
          platforms: string[] | null
          position: number | null
          prompt_text: string
          tip: string | null
          title: string
        }
        Insert: {
          category: string
          id?: string
          is_active?: boolean | null
          platforms?: string[] | null
          position?: number | null
          prompt_text: string
          tip?: string | null
          title: string
        }
        Update: {
          category?: string
          id?: string
          is_active?: boolean | null
          platforms?: string[] | null
          position?: number | null
          prompt_text?: string
          tip?: string | null
          title?: string
        }
        Relationships: []
      }
      rl_buckets: {
        Row: {
          count: number
          key: string
          window_start: string
        }
        Insert: {
          count?: number
          key: string
          window_start?: string
        }
        Update: {
          count?: number
          key?: string
          window_start?: string
        }
        Relationships: []
      }
      saved_refs: {
        Row: {
          author: string | null
          caption: string | null
          created_at: string | null
          folder: string | null
          id: string
          media_type: string | null
          note: string | null
          platform: string | null
          status: string | null
          thumbnail_url: string | null
          url: string
          used_post_id: string | null
          user_id: string
        }
        Insert: {
          author?: string | null
          caption?: string | null
          created_at?: string | null
          folder?: string | null
          id?: string
          media_type?: string | null
          note?: string | null
          platform?: string | null
          status?: string | null
          thumbnail_url?: string | null
          url: string
          used_post_id?: string | null
          user_id: string
        }
        Update: {
          author?: string | null
          caption?: string | null
          created_at?: string | null
          folder?: string | null
          id?: string
          media_type?: string | null
          note?: string | null
          platform?: string | null
          status?: string | null
          thumbnail_url?: string | null
          url?: string
          used_post_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      social_connections: {
        Row: {
          access_token: string
          account_type: string | null
          connected_at: string | null
          crm_client_id: string | null
          external_account_id: string
          id: string
          profile_picture_url: string | null
          provider: string
          scopes: string | null
          token_expires_at: string | null
          updated_at: string | null
          user_id: string
          username: string | null
        }
        Insert: {
          access_token: string
          account_type?: string | null
          connected_at?: string | null
          crm_client_id?: string | null
          external_account_id: string
          id?: string
          profile_picture_url?: string | null
          provider?: string
          scopes?: string | null
          token_expires_at?: string | null
          updated_at?: string | null
          user_id: string
          username?: string | null
        }
        Update: {
          access_token?: string
          account_type?: string | null
          connected_at?: string | null
          crm_client_id?: string | null
          external_account_id?: string
          id?: string
          profile_picture_url?: string | null
          provider?: string
          scopes?: string | null
          token_expires_at?: string | null
          updated_at?: string | null
          user_id?: string
          username?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "social_connections_crm_client_id_fkey"
            columns: ["crm_client_id"]
            isOneToOne: false
            referencedRelation: "crm_clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "social_connections_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      social_insights: {
        Row: {
          caption: string | null
          captured_at: string | null
          id: string
          media_type: string | null
          metrics: Json
          object_id: string | null
          object_type: string
          permalink: string | null
          post_id: string | null
          posted_at: string | null
          provider: string
          thumbnail_url: string | null
          user_id: string
        }
        Insert: {
          caption?: string | null
          captured_at?: string | null
          id?: string
          media_type?: string | null
          metrics?: Json
          object_id?: string | null
          object_type: string
          permalink?: string | null
          post_id?: string | null
          posted_at?: string | null
          provider?: string
          thumbnail_url?: string | null
          user_id: string
        }
        Update: {
          caption?: string | null
          captured_at?: string | null
          id?: string
          media_type?: string | null
          metrics?: Json
          object_id?: string | null
          object_type?: string
          permalink?: string | null
          post_id?: string | null
          posted_at?: string | null
          provider?: string
          thumbnail_url?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "social_insights_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "social_insights_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      social_metrics_daily: {
        Row: {
          accounts_engaged: number | null
          captured_at: string | null
          date: string
          followers: number | null
          id: string
          impressions: number | null
          metrics: Json
          profile_views: number | null
          provider: string
          reach: number | null
          total_interactions: number | null
          user_id: string
          website_clicks: number | null
        }
        Insert: {
          accounts_engaged?: number | null
          captured_at?: string | null
          date: string
          followers?: number | null
          id?: string
          impressions?: number | null
          metrics?: Json
          profile_views?: number | null
          provider?: string
          reach?: number | null
          total_interactions?: number | null
          user_id: string
          website_clicks?: number | null
        }
        Update: {
          accounts_engaged?: number | null
          captured_at?: string | null
          date?: string
          followers?: number | null
          id?: string
          impressions?: number | null
          metrics?: Json
          profile_views?: number | null
          provider?: string
          reach?: number | null
          total_interactions?: number | null
          user_id?: string
          website_clicks?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "social_metrics_daily_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      status_covers: {
        Row: {
          cover_from: string | null
          cover_to: string | null
          cover_type: string
          created_at: string | null
          id: string
          image_url: string | null
          label: string | null
          status_key: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          cover_from?: string | null
          cover_to?: string | null
          cover_type?: string
          created_at?: string | null
          id?: string
          image_url?: string | null
          label?: string | null
          status_key: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          cover_from?: string | null
          cover_to?: string | null
          cover_type?: string
          created_at?: string | null
          id?: string
          image_url?: string | null
          label?: string | null
          status_key?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "status_covers_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      story_slots: {
        Row: {
          created_at: string
          format: string | null
          id: string
          notified_at: string | null
          notify_body: string | null
          notify_title: string | null
          script: string | null
          slot_date: string
          slot_time: string | null
          sort_order: number
          source: string
          status: string
          title: string
          trend_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          format?: string | null
          id?: string
          notified_at?: string | null
          notify_body?: string | null
          notify_title?: string | null
          script?: string | null
          slot_date: string
          slot_time?: string | null
          sort_order?: number
          source?: string
          status?: string
          title: string
          trend_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          format?: string | null
          id?: string
          notified_at?: string | null
          notify_body?: string | null
          notify_title?: string | null
          script?: string | null
          slot_date?: string
          slot_time?: string | null
          sort_order?: number
          source?: string
          status?: string
          title?: string
          trend_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      story_trends: {
        Row: {
          created_at: string
          description: string | null
          example: string | null
          format: string
          id: string
          title: string
          why_trending: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          example?: string | null
          format: string
          id?: string
          title: string
          why_trending?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          example?: string | null
          format?: string
          id?: string
          title?: string
          why_trending?: string | null
        }
        Relationships: []
      }
      structured_goals: {
        Row: {
          category: string
          created_at: string | null
          current_value: number | null
          end_date: string | null
          id: string
          observation: string | null
          period: string | null
          start_date: string | null
          status: string
          target_value: number | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          category?: string
          created_at?: string | null
          current_value?: number | null
          end_date?: string | null
          id?: string
          observation?: string | null
          period?: string | null
          start_date?: string | null
          status?: string
          target_value?: number | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string | null
          current_value?: number | null
          end_date?: string | null
          id?: string
          observation?: string | null
          period?: string | null
          start_date?: string | null
          status?: string
          target_value?: number | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "structured_goals_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          amount_cents: number | null
          canceled_at: string | null
          created_at: string | null
          currency: string | null
          current_period_end: string | null
          current_period_start: string | null
          gateway: string
          gateway_customer_id: string | null
          gateway_payment_id: string | null
          gateway_subscription_id: string | null
          id: string
          plan: string
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount_cents?: number | null
          canceled_at?: string | null
          created_at?: string | null
          currency?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          gateway?: string
          gateway_customer_id?: string | null
          gateway_payment_id?: string | null
          gateway_subscription_id?: string | null
          id?: string
          plan?: string
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount_cents?: number | null
          canceled_at?: string | null
          created_at?: string | null
          currency?: string | null
          current_period_end?: string | null
          current_period_start?: string | null
          gateway?: string
          gateway_customer_id?: string | null
          gateway_payment_id?: string | null
          gateway_subscription_id?: string | null
          id?: string
          plan?: string
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      suppressed_emails: {
        Row: {
          created_at: string
          email: string
          id: string
          metadata: Json | null
          reason: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          metadata?: Json | null
          reason: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          metadata?: Json | null
          reason?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          created_at: string | null
          description: string | null
          due_date: string | null
          id: string
          post_id: string | null
          priority: string | null
          status: string | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          post_id?: string | null
          priority?: string | null
          status?: string | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          post_id?: string | null
          priority?: string | null
          status?: string | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tasks_post_id_fkey"
            columns: ["post_id"]
            isOneToOne: false
            referencedRelation: "posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      terms_acceptances: {
        Row: {
          accepted_at: string
          id: string
          ip_address: string | null
          terms_version: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          accepted_at?: string
          id?: string
          ip_address?: string | null
          terms_version: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          accepted_at?: string
          id?: string
          ip_address?: string | null
          terms_version?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "terms_acceptances_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_formats: {
        Row: {
          created_at: string | null
          id: string
          name: string
          platform: string
          structure: string
          tips: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          platform: string
          structure: string
          tips?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          platform?: string
          structure?: string
          tips?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_formats_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_hooks: {
        Row: {
          category: string
          created_at: string | null
          hook_text: string
          id: string
          is_favorite: boolean | null
          platforms: string[] | null
          user_id: string
        }
        Insert: {
          category: string
          created_at?: string | null
          hook_text: string
          id?: string
          is_favorite?: boolean | null
          platforms?: string[] | null
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string | null
          hook_text?: string
          id?: string
          is_favorite?: boolean | null
          platforms?: string[] | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_hooks_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_library_usage: {
        Row: {
          id: string
          is_user_item: boolean | null
          item_id: string
          item_type: string
          used_at: string | null
          user_id: string
        }
        Insert: {
          id?: string
          is_user_item?: boolean | null
          item_id: string
          item_type: string
          used_at?: string | null
          user_id: string
        }
        Update: {
          id?: string
          is_user_item?: boolean | null
          item_id?: string
          item_type?: string
          used_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_library_usage_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_prompts: {
        Row: {
          category: string
          created_at: string | null
          id: string
          is_favorite: boolean | null
          prompt_text: string
          tip: string | null
          title: string
          user_id: string
        }
        Insert: {
          category: string
          created_at?: string | null
          id?: string
          is_favorite?: boolean | null
          prompt_text: string
          tip?: string | null
          title: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string | null
          id?: string
          is_favorite?: boolean | null
          prompt_text?: string
          tip?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_prompts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_tour_progress: {
        Row: {
          completed: boolean
          completed_at: string | null
          id: string
          last_step: number
          tour_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          completed?: boolean
          completed_at?: string | null
          id?: string
          last_step?: number
          tour_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          completed?: boolean
          completed_at?: string | null
          id?: string
          last_step?: number
          tour_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      accept_proposal_by_token: { Args: { _token: string }; Returns: undefined }
      acts_for: { Args: { target: string }; Returns: boolean }
      admin_list_referrals: {
        Args: never
        Returns: {
          created_at: string
          currency: string
          gross_amount_cents: number
          id: string
          net_amount_cents: number
          paid_at: string
          paid_invoices_count: number
          partner_id: string
          partner_name: string
          partner_pix: string
          payout_note: string
          payout_proof_url: string
          referred_email: string
          referred_user_id: string
          status: string
          unlocked_at: string
        }[]
      }
      admin_wipe_user_content: { Args: { _user_id: string }; Returns: Json }
      agency_clients: {
        Args: never
        Returns: {
          created_at: string
          email: string
          id: string
          name: string
          parked_until: string
        }[]
      }
      agency_seats_used: { Args: never; Returns: number }
      ai_monthly_quota: { Args: never; Returns: number }
      ai_usage_this_month: {
        Args: never
        Returns: {
          quota: number
          used: number
        }[]
      }
      approve_post: { Args: { _post_id: string }; Returns: boolean }
      approve_post_by_token: {
        Args: { _post_id: string; _token: string }
        Returns: undefined
      }
      approve_stage_by_token: {
        Args: { _post_id: string; _stage: string; _token: string }
        Returns: undefined
      }
      bio_slug_available: {
        Args: { _exclude?: string; _slug: string }
        Returns: boolean
      }
      bump_ai_quota: {
        Args: { _user: string }
        Returns: {
          quota: number
          used: number
        }[]
      }
      bump_ai_rate_limit: {
        Args: { _max: number; _user: string; _window: string }
        Returns: number
      }
      bump_hub_credits: {
        Args: { _cost: number; _manager: string }
        Returns: number
      }
      can_client: {
        Args: { _client: string; _module?: string; _owner: string }
        Returns: boolean
      }
      can_client_ext: {
        Args: { _external: string; _owner: string }
        Returns: boolean
      }
      check_and_increment_rate_limit: {
        Args: {
          _limit: number
          _scope: string
          _user_id: string
          _window_key: string
        }
        Returns: {
          allowed: boolean
          current_count: number
          limit: number
        }[]
      }
      claim_account_invites: { Args: never; Returns: number }
      criapost_add_media: {
        Args: {
          p_bunny_video_id: string
          p_download_url: string
          p_external_file_id: string
          p_file_name: string
          p_file_size: number
          p_file_type: string
          p_post_id: string
          p_provider: string
          p_thumbnail_url: string
          p_view_url: string
        }
        Returns: string
      }
      criapost_reorder_media: {
        Args: { p_ids: string[]; p_post_id: string }
        Returns: undefined
      }
      criapost_touch_media: { Args: { p_post_id: string }; Returns: undefined }
      delete_email: {
        Args: { message_id: number; queue_name: string }
        Returns: boolean
      }
      email_queue_dispatch: { Args: never; Returns: undefined }
      enqueue_email: {
        Args: { payload: Json; queue_name: string }
        Returns: number
      }
      get_admin_stats: {
        Args: never
        Returns: {
          active_users_7d: number
          admins: number
          onboarded: number
          plan_free: number
          plan_pro: number
          plan_studio: number
          total_users: number
        }[]
      }
      get_admin_usage: { Args: never; Returns: Json }
      get_client_ig_media: {
        Args: { _crm_client_id: string; _since: string; _until: string }
        Returns: {
          caption: string
          media_type: string
          metrics: Json
          permalink: string
          posted_at: string
          thumbnail_url: string
        }[]
      }
      get_cronograma_by_token: { Args: { _token: string }; Returns: Json }
      get_external_client_by_token: {
        Args: { _token: string }
        Returns: {
          brand_color: string
          client_logo: string
          client_name: string
          instagram_handle: string
          manager_name: string
        }[]
      }
      get_external_handle_by_token: {
        Args: { _token: string }
        Returns: string
      }
      get_manager_notes: { Args: { _owner_id: string }; Returns: string }
      get_my_partner_referrals: {
        Args: never
        Returns: {
          created_at: string
          currency: string
          deduction_pct: number
          gross_amount_cents: number
          id: string
          net_amount_cents: number
          paid_at: string
          paid_invoices_count: number
          referred_name: string
          status: string
          unlocked_at: string
        }[]
      }
      get_portal_settings: {
        Args: { _token: string }
        Returns: {
          settings: Json
        }[]
      }
      get_proposal_by_token: { Args: { _token: string }; Returns: Json }
      get_public_bio_links_by_slug: {
        Args: { _slug: string }
        Returns: {
          icon: string
          id: string
          link_type: string
          position: number
          thumbnail_url: string
          title: string
          url: string
        }[]
      }
      get_public_profile_by_slug: {
        Args: { _slug: string }
        Returns: {
          avatar_url: string
          bio: string
          bio_settings: Json
          bio_slug: string
          id: string
          instagram_handle: string
          name: string
          niche: string
        }[]
      }
      get_token_period: {
        Args: { _token: string }
        Returns: {
          period_end: string
          period_start: string
        }[]
      }
      get_user_details: { Args: { _user_id: string }; Returns: Json }
      get_user_id_by_email: { Args: { _email: string }; Returns: string }
      has_access: { Args: never; Returns: boolean }
      has_module: { Args: { _code: string; _user?: string }; Returns: boolean }
      hub_credits_status: {
        Args: { _manager: string }
        Returns: {
          quota: number
          used: number
        }[]
      }
      increment_bio_link_click: {
        Args: { link_id: string }
        Returns: undefined
      }
      increment_bio_view: { Args: { _slug: string }; Returns: undefined }
      increment_storage: {
        Args: { _delta: number; _user: string }
        Returns: undefined
      }
      is_account_manager: { Args: { _owner: string }; Returns: boolean }
      is_admin: { Args: never; Returns: boolean }
      is_team_member: { Args: { target: string }; Returns: boolean }
      list_posts_by_token: {
        Args: { _token: string }
        Returns: {
          approval_mode: string
          approval_stages: Json
          approval_status: string
          caption: string
          content_blocks: Json
          format: string
          hook: string
          last_comment: string
          last_comment_role: string
          media: Json
          platform: string
          post_id: string
          scheduled_date: string
          script: string
          title: string
        }[]
      }
      log_app_error: {
        Args: {
          _context?: Json
          _level?: string
          _message: string
          _url?: string
        }
        Returns: undefined
      }
      manager_approval_items: {
        Args: never
        Returns: {
          approval_status: string
          approval_updated_at: string
          client_avatar: string
          client_name: string
          format: string
          last_comment: string
          last_comment_role: string
          owner_id: string
          platform: string
          post_id: string
          scheduled_date: string
          title: string
        }[]
      }
      manager_approval_overview: {
        Args: never
        Returns: {
          ajustes: number
          aprovados: number
          avatar_url: string
          name: string
          owner_id: string
          pendentes: number
        }[]
      }
      manager_client_brandbook: {
        Args: { client_owner_id: string }
        Returns: Json
      }
      manager_client_ideas: { Args: { client_owner_id: string }; Returns: Json }
      manager_client_instagram: {
        Args: { client_owner_id: string }
        Returns: Json
      }
      manager_client_posts: { Args: { client_owner_id: string }; Returns: Json }
      manager_clients_cria_profiles: {
        Args: never
        Returns: {
          avatar_url: string
          cria_owner_id: string
          name: string
          niche: string
        }[]
      }
      manager_owns_cria_client: { Args: { _owner: string }; Returns: boolean }
      move_to_dlq: {
        Args: {
          dlq_name: string
          message_id: number
          payload: Json
          source_queue: string
        }
        Returns: number
      }
      my_managed_accounts: {
        Args: never
        Returns: {
          avatar_url: string
          instagram_handle: string
          name: string
          niche: string
          owner_id: string
        }[]
      }
      my_member_permissions: {
        Args: { target: string }
        Returns: {
          all_clients: boolean
          client_ids: string[]
          module_code: string
        }[]
      }
      my_team_accounts: {
        Args: never
        Returns: {
          avatar_url: string
          instagram_handle: string
          name: string
          niche: string
          owner_id: string
        }[]
      }
      portal_mark_viewed: { Args: { _token: string }; Returns: undefined }
      rate_touch: { Args: { _key: string; _limit: number }; Returns: boolean }
      read_email_batch: {
        Args: { batch_size: number; queue_name: string; vt: number }
        Returns: {
          message: Json
          msg_id: number
          read_ct: number
        }[]
      }
      recalc_manager_storage: { Args: { _manager: string }; Returns: undefined }
      reconcile_agency_seats: { Args: { _manager: string }; Returns: number }
      refund_hub_credits: {
        Args: { _cost: number; _manager: string }
        Returns: undefined
      }
      reject_proposal_by_token: {
        Args: { _note?: string; _reason?: string; _token: string }
        Returns: undefined
      }
      request_adjustment_by_token: {
        Args: { _comment: string; _post_id: string; _token: string }
        Returns: undefined
      }
      request_post_adjustment: {
        Args: { _comment: string; _post_id: string }
        Returns: boolean
      }
      request_proposal_change_by_token: {
        Args: { _comment: string; _token: string }
        Returns: undefined
      }
      request_stage_adjustment_by_token: {
        Args: {
          _comment: string
          _post_id: string
          _stage: string
          _token: string
        }
        Returns: undefined
      }
      set_cronograma_data_by_token: {
        Args: { _data_id: string; _selected: boolean; _token: string }
        Returns: boolean
      }
      set_cronograma_item_by_token: {
        Args: {
          _comment: string
          _item_id: string
          _status: string
          _token: string
        }
        Returns: boolean
      }
      set_manager_notes: {
        Args: { _notes: string; _owner_id: string }
        Returns: undefined
      }
      submit_bio_lead: {
        Args: {
          _email?: string
          _name?: string
          _phone?: string
          _slug: string
        }
        Returns: undefined
      }
      touch_last_seen: { Args: never; Returns: undefined }
      user_tier: { Args: never; Returns: string }
      validate_partner_code: {
        Args: { _code: string }
        Returns: {
          coupon_type: string
          discount_pct: number
          duration_months: number
          partner_name: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
