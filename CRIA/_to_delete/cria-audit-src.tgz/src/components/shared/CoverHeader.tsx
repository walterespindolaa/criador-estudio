import { InfoTooltip } from "@/components/shared/InfoTooltip";

export function CoverHeader({ label, title, count, from, to, ink = "#fff", sub = "rgba(255,255,255,.78)", hint, compact }:{ label?:string; title:string; count?:number; from:string; to:string; ink?:string; sub?:string; hint?:string; compact?:boolean }) {
  return (
    <div className={`relative overflow-hidden rounded-[18px] shadow-warm-lg ${compact ? "px-4 pt-6 pb-5" : "px-5 pt-7 pb-8"}`}
         style={{ background:`linear-gradient(140deg, ${from}, ${to})`, ["--ch-ink" as string]: ink }}>
      <div className="absolute inset-0" style={{ background:'radial-gradient(80% 60% at 78% 8%, rgba(255,255,255,.22), transparent 55%)' }} />
      {label && (
        <span className="absolute top-3 left-4 flex items-center gap-1 text-[10px] font-bold tracking-[1.4px] uppercase" style={{ color: sub }}>
          {label}
          {hint && <InfoTooltip text={hint} side="bottom" className="!text-[color:var(--ch-ink)] opacity-70 hover:opacity-100" />}
        </span>
      )}
      {count!=null && <span className="absolute top-3 right-4 text-[11px] font-bold bg-white/15 px-2 py-0.5 rounded-full" style={{ color: ink }}>{count}</span>}
      <div className="relative mt-3 flex items-end" style={{ ["--ch-ink" as string]: ink }}>
        {/* leading folgado + line-clamp em vez de truncate: itálico não clipa e título
            longo quebra em 2 linhas em vez de ser cortado. */}
        <h2 className={`font-display italic font-light leading-[1.08] tracking-tight min-w-0 line-clamp-2 break-words pr-1 pb-0.5 ${compact ? "text-xl" : "text-[2.4rem]"}`}
            style={{ textShadow:'0 2px 18px rgba(0,0,0,.18)', color: ink }}>{title}</h2>
      </div>
    </div>
  );
}
