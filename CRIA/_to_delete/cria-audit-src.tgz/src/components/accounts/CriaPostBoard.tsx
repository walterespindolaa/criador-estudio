import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useExternalClients, useExternalPosts, usePortalActivity, type ExternalClient, type ExternalPost, type ExternalPostInput } from "@/hooks/useCriaPost";
import { toast } from "sonner";
import { confirmar } from "@/components/shared/Confirm";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ArtBriefDialog } from "./ArtBriefDialog";
import { ClientContentWriter } from "./ClientContentWriter";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { CronogramaBoard } from "@/components/accounts/CronogramaBoard";
import { DragDropContext, Droppable, Draggable, type DropResult } from "@hello-pangea/dnd";
import { Plus, Link2, Pencil, Loader2, ArrowLeft, Trash2, RotateCcw, FileText, Instagram, KanbanSquare, Eye, Clock, Settings2, Palette, Copy, CalendarDays, X, ChevronDown, History } from "lucide-react";
import { usePostApprovalComments } from "@/hooks/useApprovals";
import { hojeBR, parseDateOnly } from "@/lib/date-br";
import { Calendar } from "@/components/ui/calendar";
import { CriaPostMedia } from "@/components/accounts/CriaPostMedia";
import { ImportKanbanDialog } from "@/components/accounts/ImportKanbanDialog";
import { ClientReportDialog } from "@/components/accounts/ClientReportDialog";
import { ExternalClientDialog } from "@/components/accounts/ExternalClientDialog";
import { useProfile } from "@/hooks/useProfile";
import { useCrmClients } from "@/hooks/useCrm";
import { useClientSocialConnection, connectInstagram } from "@/hooks/useSocialInsights";
import { ClienteInstagramCria } from "@/components/accounts/ClienteInstagramCria";
import { FORMATS_BY_PLATFORM, FORMAT_LABELS } from "@/lib/constants";

const PLATFORMS = ["instagram", "tiktok", "youtube"];
const FORMATS = ["reels", "carrossel", "foto", "story", "video"];
// CLIENT_COLORS mudou de casa (ExternalClientDialog), re-export mantém imports antigos.
export { CLIENT_COLORS } from "@/components/accounts/ExternalClientDialog";
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
// Copia a legenda inteira preservando a formatação (quebras/parágrafos). Clipboard API
// com fallback (textarea + execCommand) pra quando o navegador não expõe o clipboard.
async function copiarLegenda(texto: string) {
  const valor = texto ?? "";
  if (!valor.trim()) { toast.error("Não há legenda pra copiar."); return; }
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(valor);
    } else {
      const ta = document.createElement("textarea");
      ta.value = valor; ta.style.position = "fixed"; ta.style.top = "-9999px"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.focus(); ta.select();
      const ok = document.execCommand("copy"); ta.remove();
      if (!ok) throw new Error("clipboard indisponível");
    }
    toast.success("Legenda copiada");
  } catch {
    toast.error("Não consegui copiar a legenda. Copie manualmente.");
  }
}
// Cor por formato: a pessoa bate o olho e sabe o que é (reels azul, carrossel verde...).
const FORMAT_COLOR: Record<string, string> = { reels: "#0061EE", carrossel: "#01A652", foto: "#EA4918", story: "#7C90F0", video: "#4B3FA8" };
function relTimeBR(iso: string): string {
  const min = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (min < 1) return "agora mesmo";
  if (min < 60) return `há ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `há ${h}h`;
  const d = Math.floor(h / 24);
  return d === 1 ? "há 1 dia" : `há ${d} dias`;
}
function daysWaiting(p: ExternalPost): number {
  const base = p.approval_updated_at ?? p.created_at;
  return Math.floor((Date.now() - new Date(base).getTime()) / 86400000);
}
// Data + hora do histórico no fuso BR (só exibição; o instante já vem em UTC do banco).
const DT_FMT_BR = new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo", day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
function fmtDateTimeBR(iso: string): string {
  try { return DT_FMT_BR.format(new Date(iso)); } catch { return ""; }
}

// Histórico de aprovação do post: TODO o vai e volta com o cliente, em ordem
// cronológica. Reaproveita post_approval_comments (todos os comentários, não só o
// último): cada pedido de ajuste do cliente ("cliente_externo") e cada reenvio
// nosso ("social_media"). Fica recolhido por padrão pra não poluir o editor.
function ApprovalHistory({ postId }: { postId: string }) {
  const { comments, isLoading } = usePostApprovalComments(postId);
  const [open, setOpen] = useState(false);
  if (isLoading || comments.length === 0) return null;
  return (
    <div className="rounded-xl border border-border bg-muted/20 overflow-hidden">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open}
        className="w-full min-h-[44px] flex items-center justify-between gap-2 px-3 py-2.5 text-left hover:bg-muted/40 transition-colors">
        <span className="flex items-center gap-1.5 text-xs font-body font-bold text-foreground">
          <History className="h-3.5 w-3.5 text-muted-foreground" /> Histórico de aprovação ({comments.length})
        </span>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="px-3 pb-3 space-y-2 max-h-72 overflow-y-auto">
          {comments.map((c) => {
            // "cliente_externo" (portal por link) e "cliente" (aprovação interna) = o cliente.
            const isClient = c.author_role === "cliente_externo" || c.author_role === "cliente";
            return (
              <div key={c.id} className={`rounded-lg border px-2.5 py-2 ${isClient ? "border-orange-100 bg-orange-50" : "border-primary/15 bg-primary/[0.04]"}`}>
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className={`text-[11px] font-body font-bold ${isClient ? "text-orange-700" : "text-primary"}`}>{isClient ? "Cliente" : "Você"}</span>
                  <span className="text-[10px] font-body text-muted-foreground shrink-0">{fmtDateTimeBR(c.created_at)}</span>
                </div>
                <p className="text-[12.5px] font-body text-foreground whitespace-pre-wrap leading-relaxed">{c.content}</p>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
const STATUS: Record<string, { label: string; cls: string }> = {
  em_producao: { label: "Em produção", cls: "bg-violet-100 text-violet-700" },
  pendente: { label: "Aguardando cliente", cls: "bg-amber-100 text-amber-700" },
  ajuste_solicitado: { label: "Ajuste solicitado", cls: "bg-orange-100 text-orange-700" },
  aprovado: { label: "Aprovado", cls: "bg-green-100 text-green-700" },
  postado: { label: "Postado", cls: "bg-slate-200 text-slate-600" },
};
// 5 status: post nasce em produção; a social mídia libera pro cliente (aguardando);
// cliente aprova ou pede ajuste; depois de publicado, vai pra Postado.
const APPROVAL_COLS = ["em_producao", "pendente", "ajuste_solicitado", "aprovado", "postado"] as const;
type ApprovalKey = (typeof APPROVAL_COLS)[number];

// ── Filtro de data + formato do board (Produção). Persiste por dispositivo pra
// voltar do jeito que a pessoa deixou, até ela limpar.
const FILTER_KEY = "criapost_filter_v1";
const PRESET_DAYS: Record<string, number> = { "7": 7, "15": 15, "30": 30, "60": 60 };
type PostFilter = {
  preset: "all" | "7" | "15" | "30" | "60" | "custom"; // atalho de período
  from: string; // YYYY-MM-DD (só quando preset = custom)
  to: string;   // YYYY-MM-DD (só quando preset = custom)
  fmt: string;  // "all" | formato
};
const FILTER_DEFAULT: PostFilter = { preset: "all", from: "", to: "", fmt: "all" };

// Carrega o filtro salvo. Se um dia existir o esquema antigo (mês/formato solto),
// migramos: o mês YYYY-MM vira um intervalo custom daquele mês.
function loadPostFilter(): PostFilter {
  try {
    const raw = localStorage.getItem(FILTER_KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<PostFilter>;
      const presets = ["all", "7", "15", "30", "60", "custom"];
      return {
        preset: (presets.includes(p.preset as string) ? p.preset : "all") as PostFilter["preset"],
        from: typeof p.from === "string" ? p.from : "",
        to: typeof p.to === "string" ? p.to : "",
        fmt: typeof p.fmt === "string" ? p.fmt : "all",
      };
    }
    // Migração best-effort do esquema antigo (nunca chegou a persistir, mas fica o gancho).
    const oldMes = localStorage.getItem("criapost_mes"); // "YYYY-MM"
    const oldFmt = localStorage.getItem("criapost_fmt");
    if (oldMes || oldFmt) {
      const migrated = { ...FILTER_DEFAULT };
      if (oldMes && /^\d{4}-\d{2}$/.test(oldMes)) {
        const [y, m] = oldMes.split("-").map(Number);
        const last = new Date(y, m, 0).getDate(); // último dia do mês
        migrated.preset = "custom";
        migrated.from = `${oldMes}-01`;
        migrated.to = `${oldMes}-${String(last).padStart(2, "0")}`;
      }
      if (oldFmt) migrated.fmt = oldFmt;
      try { localStorage.removeItem("criapost_mes"); localStorage.removeItem("criapost_fmt"); } catch { /* segue */ }
      return migrated;
    }
  } catch { /* segue */ }
  return { ...FILTER_DEFAULT };
}

// Intervalo efetivo (YYYY-MM-DD) do filtro. Preset "últimos N dias" = janela
// inclusiva terminando hoje (fuso BR). null = sem limite naquela ponta.
function filterRange(f: PostFilter): { from: string | null; to: string | null } {
  if (f.preset === "all") return { from: null, to: null };
  if (f.preset === "custom") return { from: f.from || null, to: f.to || null };
  const n = PRESET_DAYS[f.preset] ?? 0;
  const to = hojeBR();
  const d = parseDateOnly(to);
  d.setDate(d.getDate() - (n - 1));
  const from = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return { from, to };
}

// DD/MM só pra rótulo do chip. A string já é YYYY-MM-DD (date, sem fuso), então
// dá pra fatiar direto sem passar por Date (evita off-by-one).
function ddmm(iso: string): string {
  if (!iso) return "";
  const [, m, d] = iso.split("-");
  return `${d}/${m}`;
}

// DD/MM/AAAA pro gatilho do campo de data.
function ddmmyyyy(iso: string): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}
// Date -> YYYY-MM-DD pelos componentes locais (dia de calendário, sem UTC).
function isoFromDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
// Campo de data visual: clica -> abre o calendário shadcn num popover; seleciona
// o dia -> fecha e guarda como string YYYY-MM-DD (fuso BR). Mesmo padrao do TasksTab.
function DateField({ label, value, onChange }: { label: string; value: string; onChange: (iso: string) => void }) {
  const [open, setOpen] = useState(false);
  const selected = value ? parseDateOnly(value) : undefined;
  return (
    <div className="flex-1 min-w-0">
      <Label className="text-[11px] font-body text-muted-foreground">{label}</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button type="button" className="mt-1 flex w-full items-center gap-1.5 h-10 rounded-lg border border-input bg-card px-2.5 text-sm text-foreground">
            <CalendarDays className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            <span className="truncate">{value ? ddmmyyyy(value) : "dd/mm/aaaa"}</span>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar mode="single" selected={selected} defaultMonth={selected}
            onSelect={(dt) => { if (dt) { onChange(isoFromDate(dt)); setOpen(false); } }} />
        </PopoverContent>
      </Popover>
    </div>
  );
}

export function ClientDetail({ client, onBack, embedded, activeTab, onTabChange }: { client: ExternalClient; onBack?: () => void; embedded?: boolean; activeTab?: string; onTabChange?: (t: string) => void }) {
  const { posts, isLoading, create, createDraft, update, remove, moveStatus, setDate, reorderExternalPosts } = useExternalPosts(client.id);
  const qc = useQueryClient();
  // Filtro de data/formato pra revisar/enviar só o que interessa. Persistido em
  // localStorage (criapost_filter_v1) e reaplicado no F5 até a pessoa limpar.
  const [filter, setFilter] = useState<PostFilter>(() => loadPostFilter());
  useEffect(() => {
    try { localStorage.setItem(FILTER_KEY, JSON.stringify(filter)); } catch { /* segue */ }
  }, [filter]);
  const range = filterRange(filter);
  const filterActive = filter.preset !== "all" || filter.fmt !== "all";
  const formatosPost = Array.from(new Set(posts.map((p) => p.format).filter(Boolean) as string[]));
  const viewPosts = posts.filter((p) => {
    if (filter.fmt !== "all" && p.format !== filter.fmt) return false;
    // Post sem data (tipicamente "Em produção") SEMPRE aparece: só o formato o filtra.
    if (!p.scheduled_date) return true;
    if (range.from && p.scheduled_date < range.from) return false;
    if (range.to && p.scheduled_date > range.to) return false;
    return true;
  });
  // Guarda o id do rascunho aberto: se o usuário cancelar, apagamos (não vira lixo).
  const [draftId, setDraftId] = useState<string | null>(null);
  // Kanban (padrão) ou Calendário. Preferência salva por dispositivo.
  const [view, setView] = useState<"kanban" | "calendario">(() => {
    try { return (localStorage.getItem("criapost_view") as "kanban" | "calendario") || "kanban"; } catch { return "kanban"; }
  });
  const setViewPersist = (v: "kanban" | "calendario") => {
    setView(v);
    try { localStorage.setItem("criapost_view", v); } catch { /* segue */ }
  };
  const { copyLink } = useExternalClients();
  const { profile } = useProfile();
  const { data: portalViewedAt } = usePortalActivity(client.id);
  const [confirmMove, setConfirmMove] = useState<{ id: string; status: ApprovalKey } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleApprovalDragEnd = (r: DropResult) => {
    if (!r.destination) return;
    const dest = r.destination.droppableId as ApprovalKey;
    const post = posts.find((p) => p.id === r.draggableId);
    if (!post) return;
    const from = (post.approval_status ?? "pendente");
    // Avançar manualmente pra "Aprovado" sem o cliente: pede confirmação (só na mudança de coluna).
    if (from !== dest && dest === "aprovado") { setConfirmMove({ id: r.draggableId, status: dest }); return; }
    // Reordena a coluna de destino (mesma coluna OU mudança de status), gravando board_order.
    const col = viewPosts.filter((p) => (p.approval_status ?? "pendente") === dest && p.id !== r.draggableId);
    col.splice(r.destination.index, 0, post);
    const changes: { id: string; board_order: number; approval_status?: string; approval_updated_at?: string }[] = [];
    col.forEach((p, idx) => {
      const isMoved = p.id === r.draggableId;
      const cur = (p as { board_order?: number }).board_order ?? -1;
      if (!isMoved && cur === idx) return;
      const ch: { id: string; board_order: number; approval_status?: string; approval_updated_at?: string } = { id: p.id, board_order: idx };
      if (isMoved && from !== dest) { ch.approval_status = dest; ch.approval_updated_at = new Date().toISOString(); }
      changes.push(ch);
    });
    reorderExternalPosts(changes);
  };
  const { data: crmClients = [] } = useCrmClients();
  const criaOwnerId = crmClients.find((c) => c.id === client.crm_client_id)?.cria_owner_id ?? null;
  const hasCriaAccount = !!criaOwnerId;
  const { data: igConn } = useClientSocialConnection(client.crm_client_id);
  const [formOpen, setFormOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  // Personalização do cliente (logo, cores, vínculo central): antes vivia na lista do
  // Cria Post, agora acompanha o cliente aqui dentro (embutido no ClienteHub).
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<ExternalPost | null>(null);
  const [f, setF] = useState<ExternalPostInput>({ title: "", platform: "instagram", format: "reels", caption: "", hook: "", approval_mode: "fast", script: "", scheduled_date: null, scheduled_time: null, reference_url: null, drive_folder_url: null });
  const [copying, setCopying] = useState(false);
  const [briefOpen, setBriefOpen] = useState(false);

  // Novo post: cria um RASCUNHO na hora. Assim o post.id já existe e a mídia pode ser
  // anexada de cara (o storage precisa do id). O rascunho não aparece pro cliente.
  const openNew = async (day?: string) => {
    setF({ title: "", platform: "instagram", format: "reels", caption: "", hook: "", approval_mode: "fast", script: "", scheduled_date: day ?? null, scheduled_time: null, reference_url: null, drive_folder_url: null });
    setFormOpen(true);
    try {
      const draft = await createDraft.mutateAsync({ scheduled_date: day ?? null });
      setDraftId(draft.id);
      setEditing(draft);
    } catch { setFormOpen(false); }
  };
  const openEdit = (p: ExternalPost) => { setDraftId(null); setEditing(p); setF({ title: p.title, platform: p.platform, format: p.format, caption: p.caption ?? "", hook: p.hook ?? "", approval_mode: (p.approval_mode as "fast"|"flow"|"both") ?? "fast", script: p.script ?? "", scheduled_date: p.scheduled_date ?? null, scheduled_time: (p as { scheduled_time?: string | null }).scheduled_time ?? null, reference_url: p.reference_url ?? null, drive_folder_url: (p as { drive_folder_url?: string | null }).drive_folder_url ?? null }); setFormOpen(true); };

  // Cancelar um post novo apaga o rascunho (com a mídia que já subiu).
  const closeForm = async () => {
    setFormOpen(false);
    if (draftId) { await remove.mutateAsync(draftId).catch(() => { /* silencioso */ }); setDraftId(null); }
    setEditing(null);
  };

  // Novo post: só tem sentido perguntar quando é um RASCUNHO (draftId), porque é
  // ele que some ao fechar. Se qualquer campo foi preenchido (ou já subiu mídia),
  // confirma antes de descartar. Sem nada preenchido, fecha direto.
  const draftHasContent = () => {
    if ((f.title ?? "").trim() || (f.caption ?? "").trim() || (f.hook ?? "").trim() || (f.script ?? "").trim()) return true;
    if (f.scheduled_date || f.scheduled_time) return true;
    if (f.platform !== "instagram" || f.format !== "reels") return true;
    const media = draftId ? qc.getQueryData(["criapost-media", draftId]) : null;
    if (Array.isArray(media) && media.length > 0) return true;
    return false;
  };
  const requestCloseForm = async () => {
    if (draftId && draftHasContent()) {
      const ok = await confirmar({
        titulo: "Seu post não foi salvo",
        descricao: "Deseja sair mesmo assim? As informações preenchidas serão perdidas.",
        acao: "Sair sem salvar",
        cancelar: "Continuar editando",
      });
      if (!ok) return;
    }
    await closeForm();
  };

  const submit = async () => {
    if (!f.title.trim()) return;
    // Ideia / Referência: aceita só link http(s). Vazio = ok (campo opcional).
    if ((f.reference_url ?? "").trim() && !/^https?:\/\//i.test((f.reference_url ?? "").trim())) {
      toast.error("A referência precisa ser um link começando com http.");
      return;
    }
    // Pasta do Drive: mesma validação simples (link http). Vazio = ok.
    if ((f.drive_folder_url ?? "").trim() && !/^https?:\/\//i.test((f.drive_folder_url ?? "").trim())) {
      toast.error("A pasta do Drive precisa ser um link começando com http.");
      return;
    }
    if (draftId) {
      // Rascunho → cria o post em PRODUÇÃO (ainda não vai pro cliente).
      await update.mutateAsync({ id: draftId, publish: true, ...f });
      toast.success("Post criado! Está em produção. Libere pro cliente quando quiser.");
      setDraftId(null);
    } else if (editing) {
      await update.mutateAsync({ id: editing.id, resend: editing.approval_status === "ajuste_solicitado", ...f });
    } else {
      await create.mutateAsync(f);
      toast.success("Post criado! Está em produção.");
    }
    setFormOpen(false);
    setEditing(null);
  };
  const doCopy = async () => { setCopying(true); await copyLink(client.id); setCopying(false); };
  // Envio por PERÍODO: gera um link que só mostra os posts daquele intervalo.
  const [linkOpen, setLinkOpen] = useState(false);
  const [pStart, setPStart] = useState("");
  const [pEnd, setPEnd] = useState("");
  const doCopyPeriod = async () => {
    if (!pStart || !pEnd) { toast.error("Escolha o início e o fim do período."); return; }
    if (pEnd < pStart) { toast.error("O fim tem que ser depois do início."); return; }
    setCopying(true);
    await copyLink(client.id, { start: pStart, end: pEnd });
    setCopying(false); setLinkOpen(false);
  };
  const onChangePlatform = (pl: string) => {
    setF((prev) => {
      const allowed = FORMATS_BY_PLATFORM[pl] ?? [];
      const format = allowed.length && !allowed.includes(prev.format) ? allowed[0] : prev.format;
      return { ...prev, platform: pl, format };
    });
  };

  return (
    <div>
      {!embedded && (
        <>
          <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground font-body mb-4"><ArrowLeft className="h-4 w-4" /> Clientes</button>
          <div className="flex items-start justify-between gap-3 mb-5">
            <div className="min-w-0">
              <h1 className="text-2xl font-display font-extrabold text-foreground tracking-tight truncate">{client.name}</h1>
              {client.instagram_handle && <p className="text-sm text-muted-foreground font-body">@{client.instagram_handle.replace(/^@/, "")}</p>}
            </div>
            <div className="flex gap-2 shrink-0">
              {/* Link de aprovação dos POSTS (diferente do link do cronograma), nome explícito pra não confundir. */}
              <Button variant="outline" onClick={() => setLinkOpen(true)} disabled={copying}>{copying ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Link2 className="h-4 w-4 sm:mr-1.5" /> <span className="hidden sm:inline">Link dos posts</span></>}</Button>
            </div>
          </div>
        </>
      )}

      <ClientReportDialog open={reportOpen} onOpenChange={setReportOpen} client={client} posts={posts} managerName={profile?.name ?? undefined} />
      <ExternalClientDialog open={editOpen} onOpenChange={setEditOpen} client={client} />
      <ImportKanbanDialog open={importOpen} onOpenChange={setImportOpen} externalClientId={client.id} criaOwnerId={criaOwnerId} existingTitles={new Set(posts.map((p) => p.title))} />

      <Tabs value={embedded ? activeTab : undefined} defaultValue={embedded ? undefined : "posts"} onValueChange={embedded ? onTabChange : undefined} className="w-full">
        {!embedded && (
        <TabsList className="bg-card border border-border rounded-2xl p-1.5 mb-5 flex flex-wrap h-auto gap-1">
          <TabsTrigger value="posts" className="rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Posts</TabsTrigger>
          <TabsTrigger value="cronograma" className="rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Cronograma</TabsTrigger>
          <TabsTrigger value="relatorio" className="rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Relatório</TabsTrigger>
          <TabsTrigger value="instagram" className="rounded-xl data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Instagram</TabsTrigger>
        </TabsList>
        )}

        <TabsContent value="posts">
          <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
            {/* Kanban (padrão) / Calendário, as duas visões conversam: mudar a data reflete no card. */}
            <div className="inline-flex rounded-lg border border-border overflow-hidden">
              {(["kanban", "calendario"] as const).map((v) => (
                <button key={v} onClick={() => setViewPersist(v)}
                  className={`px-3 py-1.5 text-xs font-body font-semibold transition-colors ${view === v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                  {v === "kanban" ? "Kanban" : "Calendário"}
                </button>
              ))}
            </div>
            <div className="flex gap-2 flex-wrap">
              {embedded && (
                <>
                  <Button variant="outline" onClick={() => setLinkOpen(true)} disabled={copying}>{copying ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Link2 className="h-4 w-4 sm:mr-1.5" /> <span className="hidden sm:inline">Link de aprovação</span></>}</Button>
                  {/* Só na visão SOLTA do Cria Post. Dentro da ficha do cliente
                      existe a aba Portal, que faz o mesmo com mais espaço. */}
                  {!embedded && <Button variant="outline" onClick={() => setEditOpen(true)}><Settings2 className="h-4 w-4 sm:mr-1.5" /> <span className="hidden sm:inline">Personalizar</span></Button>}
                </>
              )}
              <Button variant="outline" onClick={() => setImportOpen(true)}><KanbanSquare className="h-4 w-4 sm:mr-1.5" /> <span className="hidden sm:inline">Importar do kanban</span></Button>
              <Button onClick={() => openNew()}><Plus className="h-4 w-4 mr-1.5" /> Novo post</Button>
            </div>
          </div>
      {/* Filtro de data: só Tudo (ver todos / limpar) + período específico (popover).
          Mobile-first: o "Tudo" e o período ficam lado a lado; período num popover discreto. */}
      <div className="flex gap-1.5 flex-wrap items-center mb-3">
        {([["all", "Tudo"]] as [PostFilter["preset"], string][]).map(([v, label]) => (
          <button key={v} onClick={() => setFilter((prev) => ({ ...prev, preset: v }))}
            className={`text-xs font-body font-semibold px-3 py-1.5 rounded-full border transition-colors ${filter.preset === v ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}>{label}</button>
        ))}
        <Popover>
          <PopoverTrigger asChild>
            <button className={`inline-flex items-center gap-1 text-xs font-body font-semibold px-3 py-1.5 rounded-full border transition-colors ${filter.preset === "custom" ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}>
              <CalendarDays className="h-3.5 w-3.5" />
              {filter.preset === "custom" && (filter.from || filter.to) ? `${ddmm(filter.from) || "…"} – ${ddmm(filter.to) || "…"}` : "Período"}
            </button>
          </PopoverTrigger>
          <PopoverContent align="start" className="w-64">
            <p className="text-xs font-body font-semibold text-foreground mb-2">Período específico</p>
            <div className="flex gap-2">
              <DateField label="De" value={filter.from} onChange={(iso) => setFilter((prev) => ({ ...prev, from: iso, preset: "custom" }))} />
              <DateField label="Até" value={filter.to} onChange={(iso) => setFilter((prev) => ({ ...prev, to: iso, preset: "custom" }))} />
            </div>
          </PopoverContent>
        </Popover>
        {filterActive && (
          <button onClick={() => setFilter({ ...FILTER_DEFAULT })}
            className="inline-flex items-center gap-1 text-xs font-body font-semibold px-3 py-1.5 rounded-full border border-border text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-3.5 w-3.5" /> Limpar
          </button>
        )}
      </div>
      {/* Filtro por formato: aparece quando há mais de um formato na fila. */}
      {formatosPost.length > 1 && (
        <div className="flex gap-1.5 flex-wrap mb-3">
          <button onClick={() => setFilter((prev) => ({ ...prev, fmt: "all" }))} className={`text-xs font-body font-semibold px-3 py-1.5 rounded-full border transition-colors ${filter.fmt === "all" ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}>Todos os formatos</button>
          {formatosPost.map((fmt) => (
            <button key={fmt} onClick={() => setFilter((prev) => ({ ...prev, fmt }))} className={`text-xs font-body font-semibold px-3 py-1.5 rounded-full border transition-colors ${filter.fmt === fmt ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground hover:text-foreground"}`}>{FORMAT_LABELS[fmt] ?? fmt}</button>
          ))}
        </div>
      )}
      {view === "calendario" ? (
        <PostsCalendar posts={viewPosts} onOpen={openEdit} onNewAt={(d) => openNew(d)}
          onMove={(id, d) => setDate.mutate({ id, scheduled_date: d })} />
      ) : isLoading ? (
        <div className="space-y-3">{[0, 1].map((i) => <div key={i} className="h-20 rounded-2xl bg-muted animate-pulse" />)}</div>
      ) : viewPosts.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-10 text-center">
          <p className="text-sm font-body text-foreground font-medium">{filterActive ? "Nenhum post com esse filtro" : "Nenhum post ainda"}</p>
          <p className="text-xs text-muted-foreground font-body mt-1">{filterActive ? "Ajuste o período/formato ou toque em Limpar." : "Crie um post: ele nasce em Produção. Quando estiver pronto, libere pro cliente (Aguardando)."}</p>
        </div>
      ) : (
        <DragDropContext onDragEnd={handleApprovalDragEnd}>
          <div className="flex gap-3 overflow-x-auto pb-4 -mx-1 px-1 kanban-scroll">
            {APPROVAL_COLS.map((colKey) => {
              const st = STATUS[colKey];
              const colPosts = viewPosts.filter((p) => (p.approval_status ?? "pendente") === colKey);
              return (
                <div key={colKey} className="w-[80vw] max-w-[300px] sm:w-72 shrink-0">
                  <div className="flex items-center justify-between px-2 py-2">
                    <span className={`text-[10px] font-body font-bold px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">{colPosts.length}</span>
                  </div>
                  <Droppable droppableId={colKey}>
                  {(dropP, dropS) => (
                  <div ref={dropP.innerRef} {...dropP.droppableProps}
                    className={`min-h-[260px] rounded-xl p-2 space-y-2 transition-colors ${dropS.isDraggingOver ? "bg-primary/5 ring-2 ring-primary/30" : "bg-muted/30"}`}>
                    {colPosts.map((p, idx) => (
                      <Draggable key={p.id} draggableId={p.id} index={idx}>
                      {(dragP, dragS) => (
                      <div ref={dragP.innerRef} {...dragP.draggableProps} {...dragP.dragHandleProps} style={dragP.draggableProps.style}
                        className={`bg-card border border-border rounded-xl p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition-all ${dragS.isDragging ? "shadow-warm-lg ring-2 ring-primary/40" : ""}`}>
                        <div className="flex items-start gap-2">
                          <div className="flex-1 min-w-0">
                            <span className="text-[10px] font-body font-bold uppercase tracking-wide"><span style={{ color: FORMAT_COLOR[p.format] ?? "#6b6b66" }}>{cap(p.format)}</span> <span className="text-muted-foreground">· {cap(p.platform)}</span></span>
                            <p className="font-display font-bold text-sm text-foreground truncate mt-1">{p.title}</p>
                            {/* Data direto no card, sem abrir o post. Reflete no calendário na hora. */}
                            <input type="date" value={p.scheduled_date ?? ""}
                              onClick={(e) => e.stopPropagation()}
                              onChange={(e) => { e.stopPropagation(); setDate.mutate({ id: p.id, scheduled_date: e.target.value || null }); }}
                              className="mt-1 h-9 md:h-6 w-full rounded-md border border-border bg-card px-1.5 text-[11px] font-body text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary" />
                            {p.reference_url && (
                              <a href={p.reference_url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}
                                className="mt-1 inline-flex items-center gap-1 text-[11px] font-body font-semibold text-primary hover:underline">
                                <Link2 className="h-3 w-3 shrink-0" /> Ideia / Referência
                              </a>
                            )}
                            {p.approval_status === "ajuste_solicitado" && p.last_comment && p.last_comment_role === "cliente_externo" && (
                              <div className="mt-2 text-xs font-body text-orange-700 bg-orange-50 border border-orange-100 rounded-lg px-2.5 py-1.5" title={p.last_comment}>
                                <span className="font-bold">Cliente pediu um ajuste</span>
                                <p className="line-clamp-2 opacity-90 mt-0.5">{p.last_comment}</p>
                                <span className="text-[10.5px] font-bold underline">Abrir pra ver o ajuste completo</span>
                              </div>
                            )}
                            {colKey === "pendente" && (() => {
                              const sentAt = p.approval_updated_at ?? p.created_at;
                              const seen = !!portalViewedAt && new Date(portalViewedAt) >= new Date(sentAt);
                              const wait = daysWaiting(p);
                              if (!seen && wait <= 3) return null;
                              return (
                                <div className="mt-2 space-y-1">
                                  {seen && (
                                    <p className="flex items-center gap-1 text-[10px] font-body font-semibold text-sky-700"><Eye className="h-3 w-3 shrink-0" /> Visto pelo cliente {relTimeBR(portalViewedAt!)}</p>
                                  )}
                                  {wait > 3 && (
                                    <p className="flex items-center gap-1 text-[10px] font-body font-bold text-amber-600"><Clock className="h-3 w-3 shrink-0" /> Esperando há {wait} dias</p>
                                  )}
                                </div>
                              );
                            })()}
                            <span className="inline-block mt-2 text-[9px] font-body font-bold px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">{p.approval_mode === "flow" ? "Detalhada" : p.approval_mode === "both" ? "Ambas" : "Simplificada"}</span>
                          </div>
                          <div className="flex flex-col gap-1.5 md:gap-1 shrink-0">
                            <Button variant="ghost" size="sm" className="h-9 w-9 md:h-7 md:w-7 p-0" onClick={() => openEdit(p)} aria-label="Editar"><Pencil className="h-4 w-4 md:h-3.5 md:w-3.5" /></Button>
                            <Button variant="ghost" size="sm" className="h-9 w-9 md:h-7 md:w-7 p-0 text-destructive" onClick={() => setConfirmDelete(p.id)} aria-label="Excluir"><Trash2 className="h-4 w-4 md:h-3.5 md:w-3.5" /></Button>
                          </div>
                        </div>
                      </div>
                      )}
                      </Draggable>
                    ))}
                    {colPosts.length === 0 && <div className="text-center py-10 text-muted-foreground/40 text-[10px]">vazio</div>}
                    {dropP.placeholder}
                  </div>
                  )}
                  </Droppable>
                </div>
              );
            })}
          </div>
        </DragDropContext>
      )}
        </TabsContent>

        <TabsContent value="cronograma">
          <CronogramaBoard fixedClientId={client.id} />
        </TabsContent>

        <TabsContent value="relatorio">
          <div className="rounded-2xl border border-border bg-card p-6 text-center">
            <p className="text-sm font-body text-foreground font-medium mb-1">Relatório mensal do cliente</p>
            <p className="text-xs text-muted-foreground font-body mb-4">Produção, desempenho do Instagram e análise da IA, pronto pra enviar em PDF.</p>
            <Button onClick={() => setReportOpen(true)}><FileText className="h-4 w-4 mr-1.5" /> Abrir relatório</Button>
          </div>
        </TabsContent>

        <TabsContent value="instagram">
          {client.crm_client_id && hasCriaAccount && criaOwnerId ? (
            // Cliente usa o CRIA: mostra os insights reais que ele mesmo sincronizou.
            <ClienteInstagramCria criaOwnerId={criaOwnerId} clientName={client.name} />
          ) : (
          <div className="rounded-2xl border border-border bg-card p-6 space-y-3">
            {client.crm_client_id ? (
              igConn ? (
                <div className="flex items-center gap-2 text-green-700"><Instagram className="h-5 w-5" /> <span className="font-body text-sm font-medium">Conectado: @{igConn.username ?? "conta"}</span></div>
              ) : (
                <>
                  <p className="text-sm font-body text-foreground">Este cliente não usa o CRIA. Você pode conectar o Instagram dele aqui pra puxar os insights.</p>
                  <Button onClick={() => connectInstagram(client.crm_client_id)} className="gap-1.5"><Instagram className="h-4 w-4" /> Conectar Instagram</Button>
                </>
              )
            ) : (
              <p className="text-sm font-body text-muted-foreground">Vincule este cliente ao cadastro central (no botão "Editar" do cliente, na lista) pra habilitar os insights do Instagram.</p>
            )}
          </div>
          )}
        </TabsContent>
      </Tabs>

      <AlertDialog open={!!confirmMove} onOpenChange={(o) => { if (!o) setConfirmMove(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Avançar sem o cliente aprovar?</AlertDialogTitle>
            <AlertDialogDescription>
              O cliente ainda não aprovou este post pelo link. Você está movendo manualmente para <b>Aprovado</b> e assume essa decisão.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (confirmMove) moveStatus.mutate({ id: confirmMove.id, approval_status: confirmMove.status }); setConfirmMove(null); }}>
              Sim, avançar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => { if (!o) setConfirmDelete(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir este post?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação é permanente e apaga o post do cliente. Não dá pra desfazer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => { if (confirmDelete) remove.mutate(confirmDelete); setConfirmDelete(null); }}>
              Sim, excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Link de aprovação: tudo OU um período específico */}
      <Dialog open={linkOpen} onOpenChange={setLinkOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader><DialogTitle className="font-display">Link de aprovação</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="rounded-xl border border-border p-3">
              <p className="text-sm font-body font-semibold text-foreground">Todos os posts</p>
              <p className="text-[12px] font-body text-muted-foreground mb-2">O cliente vê tudo que está na fila de aprovação.</p>
              <Button variant="outline" size="sm" onClick={async () => { await doCopy(); setLinkOpen(false); }} disabled={copying}>
                <Link2 className="h-3.5 w-3.5 mr-1.5" /> Copiar link completo
              </Button>
            </div>
            <div className="rounded-xl border border-primary/30 bg-primary/[0.04] p-3">
              <p className="text-sm font-body font-semibold text-foreground">Só um período</p>
              <p className="text-[12px] font-body text-muted-foreground mb-2">Gera um link que mostra apenas os posts agendados nesse intervalo.</p>
              <div className="flex gap-2 mb-2">
                <div className="flex-1">
                  <Label className="text-[11px] font-body text-muted-foreground">Início</Label>
                  <Input type="date" value={pStart} onChange={(e) => setPStart(e.target.value)} className="rounded-xl" />
                </div>
                <div className="flex-1">
                  <Label className="text-[11px] font-body text-muted-foreground">Fim</Label>
                  <Input type="date" value={pEnd} onChange={(e) => setPEnd(e.target.value)} className="rounded-xl" />
                </div>
              </div>
              <Button size="sm" onClick={doCopyPeriod} disabled={copying}>
                {copying ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Link2 className="h-3.5 w-3.5 mr-1.5" />} Copiar link do período
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={formOpen} onOpenChange={(o) => { if (!o) void requestCloseForm(); }}>
        <DialogContent onOpenAutoFocus={(e) => e.preventDefault()} className="max-w-md md:max-w-5xl bg-white rounded-2xl">
          <DialogHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-8">
            <DialogTitle className="font-display">{draftId || !editing ? "Novo post" : "Editar post"}</DialogTitle>
            <div className="flex items-center gap-2 shrink-0 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => void requestCloseForm()}>Cancelar</Button>
              <Button size="sm" onClick={submit} disabled={create.isPending || update.isPending || !f.title.trim()}>{(create.isPending || update.isPending) ? <Loader2 className="h-4 w-4 animate-spin" /> : draftId ? "Criar post" : editing ? (editing.approval_status === "ajuste_solicitado" ? <><RotateCcw className="h-4 w-4 mr-1.5" /> Salvar e reenviar</> : "Salvar") : "Criar post"}</Button>
            </div>
          </DialogHeader>
          {/* Duas colunas INDEPENDENTES (flex): a mídia não estica mais os campos
              da esquerda. items-start = cada coluna com a própria altura. */}
          <div className="flex flex-col md:flex-row md:gap-5 gap-4 md:items-start">

            {/* Coluna esquerda: os campos */}
            <div className="md:w-[54%] space-y-4">
              {/* Ajuste do cliente: fica AQUI, no editor, com espaço pra ler tudo
                  (no card do kanban aparece só a prévia). */}
              {editing?.approval_status === "ajuste_solicitado" && editing?.last_comment && (
                <div className="rounded-xl border border-orange-200 bg-orange-50 p-3">
                  <div className="flex items-center gap-1.5 mb-1">
                    <RotateCcw className="h-3.5 w-3.5 text-orange-700" />
                    <p className="text-xs font-body font-bold text-orange-800">O cliente pediu um ajuste</p>
                  </div>
                  <p className="text-[13px] font-body text-orange-800 whitespace-pre-wrap leading-relaxed max-h-40 overflow-y-auto">{editing.last_comment}</p>
                </div>
              )}
              {/* Histórico completo da aprovação (só ao editar um post já existente, não
                  no rascunho/novo). Guarda TODO o vai e volta pra a gestora não perder o
                  que o cliente pediu, mesmo depois de "Salvar e reenviar". */}
              {editing?.id && !draftId && <ApprovalHistory postId={editing.id} />}
              {/* Título */}
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Título *</Label>
                <Input value={f.title} onChange={(e) => setF((p) => ({ ...p, title: e.target.value }))} className="rounded-xl" />
              </div>

              {/* Plataforma + Formato */}
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold mb-1.5 block">Plataforma</label>
                  <div className="grid grid-cols-3 gap-2">
                    {PLATFORMS.map((pl) => (
                      <button key={pl} type="button" onClick={() => onChangePlatform(pl)}
                        className={`rounded-full border text-sm py-2 transition-colors ${f.platform === pl ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground"}`}>{cap(pl)}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs font-semibold mb-1.5 block">Formato</label>
                  <div className="flex flex-wrap gap-2">
                    {(FORMATS_BY_PLATFORM[f.platform] ?? FORMATS).map((ft) => (
                      <button key={ft} type="button" onClick={() => setF((p) => ({ ...p, format: ft }))}
                        className={`rounded-full border text-xs px-3 py-1.5 transition-colors ${f.format === ft ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground"}`}>{FORMAT_LABELS[ft] ?? cap(ft)}</button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tipo de aprovação */}
              <div>
                <label className="text-xs font-semibold mb-1.5 block">Tipo de aprovação</label>
                <div className="grid grid-cols-3 gap-2">
                  {([["fast","Simplificada"],["flow","Detalhada"],["both","Ambas"]] as [string,string][]).map(([v,l]) => (
                    <button key={v} type="button" onClick={() => setF((p) => ({ ...p, approval_mode: v as "fast"|"flow"|"both" }))}
                      className={`rounded-full border text-xs px-2 py-2 text-center transition-colors ${f.approval_mode === v ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground"}`}>{l}</button>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground mt-2">Simplificada = 1 clique · Detalhada = 4 etapas · Ambas = o cliente escolhe.</p>
              </div>

              {/* Cronograma: data + hora */}
              <div>
                <label className="text-xs font-semibold mb-1.5 block">Cronograma</label>
                {/* Data/Horário: lado a lado; abaixo de ~390px empilham pra o valor nunca espremer. */}
                <div className="grid grid-cols-2 gap-2 max-[390px]:grid-cols-1">
                  <div className="min-w-0">
                    <Label className="text-[11px] font-body text-muted-foreground">Data de publicação</Label>
                    <Input type="date" value={f.scheduled_date ?? ""} onChange={(e) => setF((p) => ({ ...p, scheduled_date: e.target.value || null }))} className="w-full h-10 rounded-xl" />
                  </div>
                  <div className="min-w-0">
                    <Label className="text-[11px] font-body text-muted-foreground">Horário</Label>
                    <Input type="time" value={f.scheduled_time ?? ""} onChange={(e) => setF((p) => ({ ...p, scheduled_time: e.target.value || null }))} className="w-full h-10 rounded-xl" />
                  </div>
                </div>
              </div>

              {/* Ideia / Referência: cola um link (Drive, post, Pinterest...) que fica
                  clicável no card. Mesmo padrão do "Referência" do Cronograma. */}
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Ideia / Referência (link)</Label>
                <Input value={f.reference_url ?? ""} onChange={(e) => setF((p) => ({ ...p, reference_url: e.target.value || null }))}
                  placeholder="Cole um link de inspiração (Drive, post, Pinterest...)" className="rounded-xl" />
              </div>

              {/* Pasta do Drive: link da PASTA com os materiais deste post (distinto da
                  ideia/referência acima, que é só inspiração). Aparece como atalho
                  "Abrir pasta no Drive" na página de aprovação do cliente. */}
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Pasta do Drive (link)</Label>
                <Input value={f.drive_folder_url ?? ""} onChange={(e) => setF((p) => ({ ...p, drive_folder_url: e.target.value || null }))}
                  placeholder="Cole o link da pasta do Drive com os materiais" className="rounded-xl" />
              </div>

              {/* Legenda (maior) */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <Label className="text-xs font-body">Legenda</Label>
                  <button type="button" onClick={() => copiarLegenda(f.caption ?? "")} disabled={!(f.caption ?? "").trim()}
                    className="inline-flex items-center gap-1 h-9 px-2.5 rounded-lg text-[11px] font-body font-semibold text-muted-foreground hover:text-primary hover:bg-primary/[0.06] disabled:opacity-40 disabled:pointer-events-none transition-colors">
                    <Copy className="h-3.5 w-3.5" /> Copiar legenda
                  </button>
                </div>
                <Textarea value={f.caption ?? ""} onChange={(e) => setF((p) => ({ ...p, caption: e.target.value }))} rows={8} className="rounded-xl min-h-[180px]" />
                {f.format === "story" && (f.caption ?? "").trim() !== "" && (
                  <p className="text-[11px] text-muted-foreground font-body">Story não exibe legenda. Esse texto não aparece no preview.</p>
                )}
              </div>

              {/* Roteiro / copy — sempre disponível (também no Simplificada). */}
              <div className="space-y-1.5">
                <Label className="text-xs font-body">{f.approval_mode !== "fast" ? "Roteiro / conteúdo (etapa \"Conteúdo\")" : "Roteiro / copy (carrossel, reels...)"}</Label>
                {f.approval_mode !== "fast" && (
                  <ClientContentWriter
                    crmClientId={client.crm_client_id ?? null}
                    clienteNome={client.name}
                    titulo={f.title}
                    formato={f.format}
                    valor={f.script ?? ""}
                    onChange={(texto) => setF((p) => ({ ...p, script: texto }))}
                  />
                )}
                <Textarea value={f.script ?? ""} onChange={(e) => setF((p) => ({ ...p, script: e.target.value }))} rows={6} placeholder="Copy do carrossel slide a slide, ou o roteiro do reels..." className="rounded-xl" />
              </div>
            </div>

            {/* Coluna direita: Mídia (própria altura, sem esticar a esquerda) */}
            <div className="md:w-[46%] md:sticky md:top-0">
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <label className="text-xs font-semibold">Mídia</label>
                <button type="button" onClick={() => setBriefOpen(true)}
                  className="inline-flex items-center gap-1.5 rounded-full border border-primary/30 bg-primary/[0.06] px-2.5 py-1 text-[11px] font-body font-bold text-primary hover:bg-primary/10 transition-colors">
                  <Palette className="h-3 w-3" /> Briefing de arte
                </button>
              </div>
              {editing?.id ? (
                <CriaPostMedia postId={editing.id} platform={f.platform} format={f.format}
                  caption={f.caption ?? undefined} handle={client.instagram_handle || undefined}
                  approved={editing.approval_status === "aprovado"}
                  title={f.title || undefined} referenceUrl={f.reference_url ?? null} />
              ) : (
                <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Preparando o post pra você anexar a mídia…</p>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* O briefing de arte deste post, com a marca DESTE cliente. */}
      <ArtBriefDialog
        open={briefOpen}
        onOpenChange={setBriefOpen}
        crmClientId={client.crm_client_id ?? null}
        clienteNome={client.name}
        titulo={f.title}
        formato={f.format}
        legenda={f.caption ?? undefined}
        roteiro={f.script ?? undefined}
      />
    </div>
  );
}

// ── Visão CALENDÁRIO dos posts (mês). Arrastar entre dias muda scheduled_date na hora.
// Conversa com o kanban: a mesma data aparece no card e aqui.
const CAL_WD = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
function calYmd(d: Date) { return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; }
// Semana começa no DOMINGO (padrão do iPhone/calendários BR).
function calWeekStart(d: Date) { const x = new Date(d); x.setDate(x.getDate() - x.getDay()); x.setHours(0, 0, 0, 0); return x; }

function PostsCalendar({ posts, onOpen, onNewAt, onMove }: {
  posts: ExternalPost[];
  onOpen: (p: ExternalPost) => void;
  onNewAt: (day: string) => void;
  onMove: (id: string, day: string) => void;
}) {
  const [anchor, setAnchor] = useState(() => new Date());
  // Drag nativo (HTML5): o @hello-pangea/dnd não funciona em grid de calendário.
  const [dragId, setDragId] = useState<string | null>(null);
  const [overDay, setOverDay] = useState<string | null>(null);

  const days = (() => {
    const first = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
    const start = calWeekStart(first);
    const last = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0);
    const end = calWeekStart(last); end.setDate(end.getDate() + 6);
    const n = Math.round((end.getTime() - start.getTime()) / 86400000) + 1;
    return Array.from({ length: n }, (_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
  })();

  const byDay = new Map<string, ExternalPost[]>();
  const semData: ExternalPost[] = [];
  for (const p of posts) {
    if (!p.scheduled_date) { semData.push(p); continue; }
    const arr = byDay.get(p.scheduled_date) ?? [];
    arr.push(p); byDay.set(p.scheduled_date, arr);
  }

  const today = calYmd(new Date());
  const dropOn = (day: string) => { if (dragId) onMove(dragId, day); setDragId(null); setOverDay(null); };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => setAnchor((a) => { const n = new Date(a); n.setMonth(n.getMonth() - 1); return n; })}>‹</Button>
          <span className="text-sm font-display font-bold text-foreground px-2 capitalize">{anchor.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</span>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => setAnchor((a) => { const n = new Date(a); n.setMonth(n.getMonth() + 1); return n; })}>›</Button>
          <Button variant="outline" size="sm" className="h-8 px-2 text-xs ml-1" onClick={() => setAnchor(new Date())}>Hoje</Button>
        </div>
      </div>

      <div className="hidden lg:grid lg:grid-cols-7 gap-2 mb-1">
        {CAL_WD.map((w) => <p key={w} className="text-[10px] uppercase tracking-wider font-body font-semibold text-muted-foreground text-center">{w}</p>)}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
        {days.map((d) => {
          const iso = calYmd(d);
          const list = byDay.get(iso) ?? [];
          const isToday = iso === today;
          const outMonth = d.getMonth() !== anchor.getMonth();
          return (
            <div key={iso}
              onDragOver={(e) => { e.preventDefault(); if (overDay !== iso) setOverDay(iso); }}
              onDragLeave={() => setOverDay((o) => (o === iso ? null : o))}
              onDrop={() => dropOn(iso)}
              className={`min-h-[104px] rounded-xl border p-2 flex flex-col gap-1.5 transition-colors
                ${isToday ? "border-primary bg-primary/5 ring-1 ring-primary/20" : "border-border bg-background"}
                ${outMonth ? "opacity-45" : ""}
                ${overDay === iso ? "ring-2 ring-primary/40 border-primary/60 bg-primary/5" : ""}`}>
              <div className="flex items-center justify-between">
                <span className={`text-sm font-display font-bold ${isToday ? "text-primary" : "text-foreground"}`}>{d.getDate()}</span>
                <button onClick={() => onNewAt(iso)} className="text-muted-foreground hover:text-primary" aria-label="Novo post neste dia"><Plus className="h-3.5 w-3.5" /></button>
              </div>
              {list.map((p) => {
                const st = STATUS[(p.approval_status ?? "pendente") as ApprovalKey];
                return (
                  <button key={p.id} draggable
                    onDragStart={() => setDragId(p.id)} onDragEnd={() => { setDragId(null); setOverDay(null); }}
                    type="button" onClick={() => onOpen(p)}
                    className={`rounded-lg border border-border bg-card px-1.5 py-1 text-left hover:bg-muted/40 transition-shadow cursor-grab active:cursor-grabbing ${dragId === p.id ? "opacity-50 shadow-lg" : ""}`}>
                    <span className={`text-[9px] font-body font-bold px-1.5 py-0.5 rounded-full ${st?.cls ?? ""}`}>{st?.label ?? "Pendente"}</span>
                    <p className="text-[11px] font-body font-semibold text-foreground leading-tight truncate mt-0.5">{p.title}</p>
                    <p className="text-[9px] font-body text-muted-foreground uppercase">{cap(p.format)}</p>
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Posts ainda sem data: arraste pra um dia do calendário. */}
      {semData.length > 0 && (
        <div className="mt-4 rounded-xl border border-dashed border-border p-3">
          <p className="text-[11px] font-body font-semibold text-muted-foreground uppercase tracking-wider mb-2">Sem data ({semData.length}), arraste pra um dia</p>
          <div className="flex gap-2 flex-wrap">
            {semData.map((p) => (
              <button key={p.id} draggable
                onDragStart={() => setDragId(p.id)} onDragEnd={() => { setDragId(null); setOverDay(null); }}
                type="button" onClick={() => onOpen(p)}
                className={`rounded-lg border border-border bg-card px-2 py-1.5 text-left hover:bg-muted/40 transition-shadow cursor-grab active:cursor-grabbing ${dragId === p.id ? "opacity-50 shadow-lg" : ""}`}>
                <p className="text-[11px] font-body font-semibold text-foreground truncate max-w-[160px]">{p.title}</p>
                <p className="text-[9px] font-body text-muted-foreground uppercase">{cap(p.format)}</p>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
