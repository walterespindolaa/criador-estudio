import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
  httpClient: Stripe.createFetchHttpClient(),
});

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Cliente com o JWT do usuário (pra descobrir quem é, sem confiar no body)
    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );
    const { data: { user }, error: userErr } = await userClient.auth.getUser();
    if (userErr || !user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json().catch(() => ({}));
    const plan = body?.plan;
    if (plan !== "essencial" && plan !== "pro" && plan !== "studio" && plan !== "agency") {
      return new Response(JSON.stringify({ error: "invalid_plan" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Plano de agência: assinatura com QUANTIDADE = nº de assentos (preço por assento).
    const isAgency = plan === "agency";
    // Plano de agência exige no mínimo 3 assentos.
    const seats = isAgency ? Math.max(3, Math.min(50, Math.floor(Number(body?.seats) || 3))) : 1;

    const priceId = isAgency
      ? Deno.env.get("STRIPE_PRICE_AGENCY_SEAT")!
      : plan === "studio"
      ? Deno.env.get("STRIPE_PRICE_STUDIO")!
      : plan === "essencial"
      ? Deno.env.get("STRIPE_PRICE_ESSENCIAL")!
      : Deno.env.get("STRIPE_PRICE_PRO")!;
    if (!priceId) {
      return new Response(JSON.stringify({ error: "price_not_configured" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Service client pra ler/gravar o stripe_customer_id
    const svc = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );
    const { data: profile } = await svc
      .from("profiles")
      .select("stripe_customer_id, name")
      .eq("id", user.id)
      .single();

    // Reusa customer existente ou cria
    let customerId = profile?.stripe_customer_id ?? undefined;
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: profile?.name ?? undefined,
        metadata: { app: "cria", user_id: user.id },
      });
      customerId = customer.id;
      await svc.from("profiles").update({ stripe_customer_id: customerId }).eq("id", user.id);
    }

    // ── Self-subscribe (manager assinando pra conta PF dela) ────
    // O front passa self_subscribe:true quando o user logado tem
    // user_metadata.self_subscribe_plan. Validamos via account_members:
    // owner_id=user.id (PF) + pending_self_subscribe=true.
    const selfSubRequest = body?.self_subscribe === true;
    let selfSubValidated = false;
    let selfSubManagerId: string | null = null;
    if (selfSubRequest) {
      const { data: link } = await svc.from("account_members")
        .select("member_id")
        .eq("owner_id", user.id)
        .eq("pending_self_subscribe", true)
        .maybeSingle();
      if (link) {
        selfSubValidated = true;
        selfSubManagerId = (link as { member_id: string | null }).member_id;
      }
    }

    // ── Partner code (opcional) ─────────────────────────────────
    let partnerMeta: Record<string, string> = {};
    let appliedPromotionCodeId: string | null = null;
    const rawCode = (typeof body?.partner_code === "string" ? body.partner_code : "").trim();
    if (rawCode) {
      // Escapa curingas do ILIKE (% e _). Sem isto, partner_code = "%" casaria com
      // QUALQUER parceiro aprovado e aplicaria um cupom que não é do usuário.
      const escapedCode = rawCode.replace(/([\\%_])/g, "\\$1");
      const { data: partner } = await svc
        .from("partners")
        .select("id, user_id, status, coupon_type, stripe_promotion_code_id")
        .ilike("coupon_code", escapedCode) // match exato case-insensitive
        .eq("status", "approved")
        .maybeSingle();
      if (partner) {
        const pr = partner as { id: string; user_id: string; coupon_type: string | null; stripe_promotion_code_id: string | null };
        const isAutoIndicacao = pr.user_id === user.id;
        // Exceção: self-subscribe validado E partner pertence à manager (member_id do vínculo).
        const allowAutoIndicacao = selfSubValidated && pr.user_id === selfSubManagerId;
        if (!isAutoIndicacao || allowAutoIndicacao) {
          partnerMeta = { partner_code: rawCode.toUpperCase(), partner_id: pr.id };
          if (pr.coupon_type === "client_discount" && pr.stripe_promotion_code_id) {
            appliedPromotionCodeId = pr.stripe_promotion_code_id;
          }
        }
      }
    }
    // Marca self_subscribe nas metadatas, webhook B.2 lê "1" pra NÃO gerar comissão.
    const selfSubMark: Record<string, string> = selfSubValidated ? { self_subscribe: "1" } : {};
    // ────────────────────────────────────────────────────────────

    const origin = req.headers.get("origin") ?? "https://app.criasocialclub.com.br";

    const agencyMeta: Record<string, string> = isAgency ? { seats: String(seats) } : {};
    // sid={CHECKOUT_SESSION_ID} é substituído pelo Stripe, usado como event_id do Purchase (dedupe com o webhook).
    const successUrl = isAgency ? `${origin}/socialmidia/contas?checkout=success` : `${origin}/app/obrigado?checkout=success&sid={CHECKOUT_SESSION_ID}`;
    const cancelUrl = isAgency ? `${origin}/socialmidia/contas?checkout=cancel` : `${origin}/app/assinar?checkout=cancel`;

    const sessionParams: Stripe.Checkout.SessionCreateParams = {
      mode: "subscription",
      customer: customerId,
      line_items: [{ price: priceId, quantity: seats }],
      metadata: { app: "cria", user_id: user.id, plan, ...agencyMeta, ...partnerMeta, ...selfSubMark },
      subscription_data: {
        metadata: { app: "cria", user_id: user.id, plan, ...agencyMeta, ...partnerMeta, ...selfSubMark },
      },
      success_url: successUrl,
      cancel_url: cancelUrl,
    };
    if (appliedPromotionCodeId) {
      sessionParams.discounts = [{ promotion_code: appliedPromotionCodeId }];
    } else {
      sessionParams.allow_promotion_codes = true;
    }
    const session = await stripe.checkout.sessions.create(sessionParams);

    return new Response(JSON.stringify({ url: session.url }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[create-checkout] error:", err);
    return new Response(JSON.stringify({ error: "internal_error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
